LOCAL_PATH := $(call my-dir)

NATIVE_ROOT := $(abspath $(LOCAL_PATH)/../..)
REPO_ROOT := $(abspath $(NATIVE_ROOT)/..)
DONOR_CPP := $(REPO_ROOT)/vendor/pico-openxr-demos/app/src/main/cpp

include $(CLEAR_VARS)
LOCAL_MODULE := openxr_loader
LOCAL_SRC_FILES := ../../../vendor/pico-openxr-demos/app/src/main/cpp/openxr_loader/lib/$(TARGET_ARCH_ABI)/libopenxr_loader.so
include $(PREBUILT_SHARED_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := fourdpico4
LOCAL_CPPFLAGS += -std=c++17 -Wall -Wextra -Wpedantic -Werror=return-type
# OpenXR C structs intentionally use {XR_TYPE_*} aggregate initialization;
# the remaining fields are zero-initialized by C++ and Clang otherwise emits noise.
LOCAL_CPPFLAGS += -Wno-missing-field-initializers
LOCAL_CPPFLAGS += -DXR_USE_PLATFORM_ANDROID=1 -DXR_USE_GRAPHICS_API_OPENGL_ES=1
LOCAL_C_INCLUDES += $(NATIVE_ROOT)
LOCAL_C_INCLUDES += $(DONOR_CPP)/openxr_loader/include
LOCAL_SRC_FILES := native_main.cpp \
                   openxr_app.cpp \
                   gles_renderer.cpp \
                   hand_gesture.cpp \
                   ../../core/math4.cpp \
                   ../../core/trackball4.cpp \
                   ../../core/tesseract.cpp \
                   ../../core/trackball_mapping.cpp \
                   ../../core/projection4.cpp \
                   ../../core/interaction.cpp \
                   ../../core/render_packet.cpp
LOCAL_LDLIBS := -llog -landroid -ldl -lEGL -lGLESv3
LOCAL_STATIC_LIBRARIES := android_native_app_glue
LOCAL_SHARED_LIBRARIES := openxr_loader
include $(BUILD_SHARED_LIBRARY)

$(call import-module,android/native_app_glue)
