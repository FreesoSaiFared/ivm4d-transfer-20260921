#pragma once

#include "core/math4.h"

namespace fourd::android {

struct HandGestureInput {
    bool active{false};
    Vec3 palm{};
    Vec3 wrist{};
    Vec3 middleMetacarpal{};
    Vec3 thumbTip{};
    Vec3 indexTip{};
    Vec3 middleTip{};
    Vec3 ringTip{};
    Vec3 littleTip{};
};

struct HandGestureConfig {
    double minimumHandScale{0.04};
    double pinchPressRatio{0.35};
    double pinchReleaseRatio{0.50};
    double squeezePressRatio{1.00};
    double squeezeReleaseRatio{1.25};
};

struct HandGestureState {
    bool active{false};
    Vec3 position{};
    bool pinch{false};
    bool squeeze{false};
    double handScale{0.0};
    double pinchRatio{0.0};
    double squeezeRatio{0.0};
};

HandGestureState evaluateHandGesture(const HandGestureInput& input,
                                     const HandGestureState& previous = {},
                                     HandGestureConfig config = {});

}  // namespace fourd::android
