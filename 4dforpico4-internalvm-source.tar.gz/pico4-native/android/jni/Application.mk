APP_ABI := arm64-v8a
APP_PLATFORM := android-29
APP_STL := c++_static
APP_CPPFLAGS := -std=c++17 -fexceptions -frtti
APP_OPTIM := debug
