#pragma once

#include "gles_renderer.h"
#include "hand_gesture.h"
#include "core/interaction.h"
#include "core/projection4.h"
#include "core/tesseract.h"

#include <android_native_app_glue.h>
#include <openxr/openxr_platform.h>

#include <array>
#include <cstdint>
#include <string>
#include <unordered_set>
#include <vector>

namespace fourd::android {

class OpenXrApp {
public:
    explicit OpenXrApp(android_app* app);
    ~OpenXrApp();
    OpenXrApp(const OpenXrApp&) = delete;
    OpenXrApp& operator=(const OpenXrApp&) = delete;

    bool initialize();
    void pollEvents();
    bool renderFrame();
    void onResume(bool resumed) { resumed_ = resumed; }
    bool shouldExit() const { return exit_requested_; }
    bool sessionRunning() const { return session_running_; }
    const std::string& lastError() const { return last_error_; }

private:
    struct Swapchain {
        XrSwapchain handle{XR_NULL_HANDLE};
        int32_t width{0};
        int32_t height{0};
        std::vector<XrSwapchainImageOpenGLESKHR> images;
    };

    struct ButtonTracker {
        bool previous{false};
        ButtonFrame sample(bool current);
        void reset() { previous = false; }
    };

    bool fail(const std::string& message);
    bool check(XrResult result, const char* operation);
    bool initializeLoader();
    bool enumerateExtensions();
    bool createInstance();
    bool createSystem();
    bool createSession();
    bool createReferenceSpace();
    bool createActions();
    bool createSwapchains();
    bool initializeOptionalFeatures();
    bool updateInteraction(XrTime displayTime);
    bool renderProjectionLayer(XrTime displayTime,
                               XrCompositionLayerProjection* layer,
                               std::vector<XrCompositionLayerProjectionView>* views);
    void applyHaptic(XrPath handPath, float amplitude, XrDuration duration);
    void configureRefreshRate();
    void initializePassthrough();
    void initializeHandTracking();
    void initializeFoveation();
    void locateHands(XrTime displayTime);
    void handleSessionState(XrSessionState state);
    void shutdown();

    bool extensionAvailable(const char* name) const;
    bool suggestControllerBindings(const char* profilePath);
    XrPath path(const char* text);

    android_app* app_{nullptr};
    GlesRenderer renderer_{};
    Tesseract tesseract_{};
    Projection4 projection_{2.0};
    Interaction interaction_;

    std::unordered_set<std::string> available_extensions_;
    XrInstance instance_{XR_NULL_HANDLE};
    XrSystemId system_id_{XR_NULL_SYSTEM_ID};
    XrSession session_{XR_NULL_HANDLE};
    XrSpace app_space_{XR_NULL_HANDLE};
    XrSessionState session_state_{XR_SESSION_STATE_UNKNOWN};
    bool session_running_{false};
    bool exit_requested_{false};
    bool resumed_{false};

    XrActionSet action_set_{XR_NULL_HANDLE};
    XrAction grip_pose_action_{XR_NULL_HANDLE};
    XrAction trigger_action_{XR_NULL_HANDLE};
    XrAction squeeze_action_{XR_NULL_HANDLE};
    XrAction haptic_action_{XR_NULL_HANDLE};
    XrAction toggle_action_{XR_NULL_HANDLE};
    XrAction reset_action_{XR_NULL_HANDLE};
    std::array<XrPath, 2> hand_paths_{{XR_NULL_PATH, XR_NULL_PATH}};
    std::array<XrSpace, 2> grip_spaces_{{XR_NULL_HANDLE, XR_NULL_HANDLE}};
    ButtonTracker trigger_tracker_{};
    ButtonTracker right_squeeze_tracker_{};
    ButtonTracker left_squeeze_tracker_{};
    ButtonTracker toggle_tracker_{};
    ButtonTracker reset_tracker_{};

    std::vector<XrViewConfigurationView> config_views_;
    std::vector<XrView> xr_views_;
    std::vector<Swapchain> swapchains_;
    int64_t swapchain_format_{0};

    bool support_bd_controller_{false};
    bool support_refresh_rate_{false};
    bool support_passthrough_{false};
    bool support_hand_tracking_{false};
    bool support_foveation_{false};
    bool passthrough_active_{false};
    bool foveation_active_{false};

    XrPassthroughFB passthrough_{XR_NULL_HANDLE};
    XrPassthroughLayerFB passthrough_layer_{XR_NULL_HANDLE};
    XrFoveationProfileFB foveation_profile_{XR_NULL_HANDLE};
    std::array<XrHandTrackerEXT, 2> hand_trackers_{{XR_NULL_HANDLE, XR_NULL_HANDLE}};
    std::array<HandGestureState, 2> hand_gestures_{};

    PFN_xrEnumerateDisplayRefreshRatesFB enumerate_refresh_rates_{nullptr};
    PFN_xrGetDisplayRefreshRateFB get_refresh_rate_{nullptr};
    PFN_xrRequestDisplayRefreshRateFB request_refresh_rate_{nullptr};
    PFN_xrCreatePassthroughFB create_passthrough_{nullptr};
    PFN_xrDestroyPassthroughFB destroy_passthrough_{nullptr};
    PFN_xrPassthroughStartFB start_passthrough_{nullptr};
    PFN_xrCreatePassthroughLayerFB create_passthrough_layer_{nullptr};
    PFN_xrDestroyPassthroughLayerFB destroy_passthrough_layer_{nullptr};
    PFN_xrPassthroughLayerResumeFB resume_passthrough_layer_{nullptr};
    PFN_xrCreateHandTrackerEXT create_hand_tracker_{nullptr};
    PFN_xrDestroyHandTrackerEXT destroy_hand_tracker_{nullptr};
    PFN_xrLocateHandJointsEXT locate_hand_joints_{nullptr};
    PFN_xrCreateFoveationProfileFB create_foveation_profile_{nullptr};
    PFN_xrDestroyFoveationProfileFB destroy_foveation_profile_{nullptr};
    PFN_xrUpdateSwapchainFB update_swapchain_{nullptr};

    std::string last_error_;
};

}  // namespace fourd::android
