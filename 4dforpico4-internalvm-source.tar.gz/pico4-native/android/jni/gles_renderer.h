#pragma once

#include "core/render_packet.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <jni.h>
#include <openxr/openxr_platform.h>

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace fourd::android {

struct Mat4f {
    std::array<float, 16> v{};
    static Mat4f identity();
};

Mat4f multiply(const Mat4f& a, const Mat4f& b);
Mat4f projectionFromFov(const XrFovf& fov, float nearZ, float farZ);
Mat4f viewFromPose(const XrPosef& pose);

class GlesRenderer {
public:
    GlesRenderer() = default;
    ~GlesRenderer();
    GlesRenderer(const GlesRenderer&) = delete;
    GlesRenderer& operator=(const GlesRenderer&) = delete;

    bool initialize(XrInstance instance, XrSystemId systemId, std::string* error);
    void shutdown();
    bool valid() const { return context_ != EGL_NO_CONTEXT && program_ != 0; }
    const XrGraphicsBindingOpenGLESAndroidKHR& graphicsBinding() const { return binding_; }
    bool render(GLuint colorTexture,
                int32_t width,
                int32_t height,
                const XrPosef& eyePose,
                const XrFovf& eyeFov,
                const RenderPacket& packet,
                bool transparentBackground,
                std::string* error);

private:
    bool createContext(std::string* error);
    bool createProgram(std::string* error);
    static GLuint compileShader(GLenum type, const char* source, std::string* error);
    void destroyGlObjects();

    EGLDisplay display_{EGL_NO_DISPLAY};
    EGLConfig config_{nullptr};
    EGLContext context_{EGL_NO_CONTEXT};
    EGLSurface surface_{EGL_NO_SURFACE};
    XrGraphicsBindingOpenGLESAndroidKHR binding_{XR_TYPE_GRAPHICS_BINDING_OPENGL_ES_ANDROID_KHR};

    GLuint program_{0};
    GLuint vao_{0};
    GLuint vbo_{0};
    GLuint framebuffer_{0};
    GLint mvp_location_{-1};
};

}  // namespace fourd::android
