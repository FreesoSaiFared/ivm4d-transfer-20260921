#include "openxr_app.h"

#include "core/render_packet.h"

#include <android/log.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>
#include <sstream>

namespace fourd::android {
namespace {
constexpr const char* kTag = "4DForPico4";
constexpr int kLeft = 0;
constexpr int kRight = 1;
constexpr float kPressThreshold = 0.55f;

void logInfo(const std::string& text) {
    __android_log_print(ANDROID_LOG_INFO, kTag, "%s", text.c_str());
}
void logWarn(const std::string& text) {
    __android_log_print(ANDROID_LOG_WARN, kTag, "%s", text.c_str());
}
void logError(const std::string& text) {
    __android_log_print(ANDROID_LOG_ERROR, kTag, "%s", text.c_str());
}

InteractionConfig makeInteractionConfig() {
    InteractionConfig config;
    config.defaultTranslation = {0.0, 1.3, -0.65};
    config.minimumScale = 0.2;
    config.maximumScale = 10.0;
    config.defaultScale = 1.0;
    config.defaultProjection = ProjectionMode::Orthographic;
    return config;
}

bool validPose(const XrSpaceLocation& location) {
    constexpr XrSpaceLocationFlags needed =
        XR_SPACE_LOCATION_POSITION_VALID_BIT | XR_SPACE_LOCATION_ORIENTATION_VALID_BIT;
    return (location.locationFlags & needed) == needed;
}

Vec3 toVec3(const XrVector3f& p) { return {p.x, p.y, p.z}; }

void copyName(char* dst, std::size_t capacity, const char* source) {
    if (!dst || capacity == 0) return;
    std::snprintf(dst, capacity, "%s", source ? source : "");
}

}  // namespace

ButtonFrame OpenXrApp::ButtonTracker::sample(bool current) {
    ButtonFrame out;
    out.down = current && !previous;
    out.held = current;
    out.up = !current && previous;
    previous = current;
    return out;
}

OpenXrApp::OpenXrApp(android_app* app)
    : app_(app), interaction_(makeInteractionConfig()) {}

OpenXrApp::~OpenXrApp() { shutdown(); }

bool OpenXrApp::fail(const std::string& message) {
    last_error_ = message;
    logError(message);
    return false;
}

bool OpenXrApp::check(XrResult result, const char* operation) {
    if (XR_SUCCEEDED(result)) return true;
    std::ostringstream stream;
    stream << operation << " failed with XrResult=" << static_cast<int>(result);
    return fail(stream.str());
}

bool OpenXrApp::initializeLoader() {
    PFN_xrInitializeLoaderKHR initializeLoader = nullptr;
    const XrResult procResult = xrGetInstanceProcAddr(
        XR_NULL_HANDLE, "xrInitializeLoaderKHR",
        reinterpret_cast<PFN_xrVoidFunction*>(&initializeLoader));
    if (XR_FAILED(procResult) || !initializeLoader) return fail("xrInitializeLoaderKHR unavailable");

    XrLoaderInitInfoAndroidKHR info{XR_TYPE_LOADER_INIT_INFO_ANDROID_KHR};
    info.applicationVM = app_->activity->vm;
    info.applicationContext = app_->activity->clazz;
    return check(initializeLoader(reinterpret_cast<const XrLoaderInitInfoBaseHeaderKHR*>(&info)),
                 "xrInitializeLoaderKHR");
}

bool OpenXrApp::enumerateExtensions() {
    uint32_t count = 0;
    if (!check(xrEnumerateInstanceExtensionProperties(nullptr, 0, &count, nullptr),
               "xrEnumerateInstanceExtensionProperties(count)")) return false;
    std::vector<XrExtensionProperties> properties(count, {XR_TYPE_EXTENSION_PROPERTIES});
    if (!check(xrEnumerateInstanceExtensionProperties(nullptr, count, &count, properties.data()),
               "xrEnumerateInstanceExtensionProperties")) return false;
    available_extensions_.clear();
    for (const auto& property : properties) available_extensions_.insert(property.extensionName);

    if (!extensionAvailable(XR_KHR_ANDROID_CREATE_INSTANCE_EXTENSION_NAME))
        return fail("runtime lacks XR_KHR_android_create_instance");
    if (!extensionAvailable(XR_KHR_OPENGL_ES_ENABLE_EXTENSION_NAME))
        return fail("runtime lacks XR_KHR_opengl_es_enable");

    support_bd_controller_ = extensionAvailable(XR_BD_CONTROLLER_INTERACTION_EXTENSION_NAME);
    support_refresh_rate_ = extensionAvailable(XR_FB_DISPLAY_REFRESH_RATE_EXTENSION_NAME);
    support_passthrough_ = extensionAvailable(XR_FB_PASSTHROUGH_EXTENSION_NAME);
    support_hand_tracking_ = extensionAvailable(XR_EXT_HAND_TRACKING_EXTENSION_NAME);
    support_foveation_ = extensionAvailable(XR_FB_FOVEATION_EXTENSION_NAME) &&
                         extensionAvailable(XR_FB_FOVEATION_CONFIGURATION_EXTENSION_NAME) &&
                         extensionAvailable(XR_FB_SWAPCHAIN_UPDATE_STATE_EXTENSION_NAME) &&
                         extensionAvailable(XR_FB_SWAPCHAIN_UPDATE_STATE_OPENGL_ES_EXTENSION_NAME);
    return true;
}

bool OpenXrApp::extensionAvailable(const char* name) const {
    return name && available_extensions_.find(name) != available_extensions_.end();
}

bool OpenXrApp::createInstance() {
    std::vector<const char*> extensions{
        XR_KHR_ANDROID_CREATE_INSTANCE_EXTENSION_NAME,
        XR_KHR_OPENGL_ES_ENABLE_EXTENSION_NAME,
    };
    if (support_bd_controller_) extensions.push_back(XR_BD_CONTROLLER_INTERACTION_EXTENSION_NAME);
    if (support_refresh_rate_) extensions.push_back(XR_FB_DISPLAY_REFRESH_RATE_EXTENSION_NAME);
    if (support_passthrough_) extensions.push_back(XR_FB_PASSTHROUGH_EXTENSION_NAME);
    if (support_hand_tracking_) extensions.push_back(XR_EXT_HAND_TRACKING_EXTENSION_NAME);
    if (support_foveation_) {
        extensions.push_back(XR_FB_FOVEATION_EXTENSION_NAME);
        extensions.push_back(XR_FB_FOVEATION_CONFIGURATION_EXTENSION_NAME);
        extensions.push_back(XR_FB_SWAPCHAIN_UPDATE_STATE_EXTENSION_NAME);
        extensions.push_back(XR_FB_SWAPCHAIN_UPDATE_STATE_OPENGL_ES_EXTENSION_NAME);
    }

    XrInstanceCreateInfoAndroidKHR androidInfo{XR_TYPE_INSTANCE_CREATE_INFO_ANDROID_KHR};
    androidInfo.applicationVM = app_->activity->vm;
    androidInfo.applicationActivity = app_->activity->clazz;

    XrInstanceCreateInfo createInfo{XR_TYPE_INSTANCE_CREATE_INFO};
    createInfo.next = &androidInfo;
    copyName(createInfo.applicationInfo.applicationName, XR_MAX_APPLICATION_NAME_SIZE, "4D for PICO 4");
    copyName(createInfo.applicationInfo.engineName, XR_MAX_ENGINE_NAME_SIZE, "portable-4d-core");
    createInfo.applicationInfo.applicationVersion = 1;
    createInfo.applicationInfo.engineVersion = 1;
    createInfo.applicationInfo.apiVersion = XR_CURRENT_API_VERSION;
    createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    createInfo.enabledExtensionNames = extensions.data();
    return check(xrCreateInstance(&createInfo, &instance_), "xrCreateInstance");
}

bool OpenXrApp::createSystem() {
    XrSystemGetInfo info{XR_TYPE_SYSTEM_GET_INFO};
    info.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    if (!check(xrGetSystem(instance_, &info, &system_id_), "xrGetSystem")) return false;

    XrSystemHandTrackingPropertiesEXT handProperties{XR_TYPE_SYSTEM_HAND_TRACKING_PROPERTIES_EXT};
    XrSystemProperties properties{XR_TYPE_SYSTEM_PROPERTIES};
    if (support_hand_tracking_) properties.next = &handProperties;
    if (!check(xrGetSystemProperties(instance_, system_id_, &properties), "xrGetSystemProperties")) return false;
    if (support_hand_tracking_ && handProperties.supportsHandTracking != XR_TRUE) {
        support_hand_tracking_ = false;
        logWarn("XR_EXT_hand_tracking advertised but system reports no hand tracking support");
    }
    std::ostringstream stream;
    stream << "OpenXR system: " << properties.systemName
           << " maxSwapchain=" << properties.graphicsProperties.maxSwapchainImageWidth
           << "x" << properties.graphicsProperties.maxSwapchainImageHeight;
    logInfo(stream.str());
    return true;
}

bool OpenXrApp::createSession() {
    std::string error;
    if (!renderer_.initialize(instance_, system_id_, &error)) return fail("GLES init: " + error);

    XrSessionCreateInfo info{XR_TYPE_SESSION_CREATE_INFO};
    info.next = &renderer_.graphicsBinding();
    info.systemId = system_id_;
    return check(xrCreateSession(instance_, &info, &session_), "xrCreateSession");
}

bool OpenXrApp::createReferenceSpace() {
    uint32_t count = 0;
    if (!check(xrEnumerateReferenceSpaces(session_, 0, &count, nullptr),
               "xrEnumerateReferenceSpaces(count)")) return false;
    std::vector<XrReferenceSpaceType> spaces(count);
    if (!check(xrEnumerateReferenceSpaces(session_, count, &count, spaces.data()),
               "xrEnumerateReferenceSpaces")) return false;
    const bool hasStage = std::find(spaces.begin(), spaces.end(), XR_REFERENCE_SPACE_TYPE_STAGE) != spaces.end();

    XrReferenceSpaceCreateInfo info{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
    info.referenceSpaceType = hasStage ? XR_REFERENCE_SPACE_TYPE_STAGE : XR_REFERENCE_SPACE_TYPE_LOCAL;
    info.poseInReferenceSpace.orientation.w = 1.0f;
    if (!check(xrCreateReferenceSpace(session_, &info, &app_space_), "xrCreateReferenceSpace")) return false;
    logInfo(hasStage ? "Using STAGE reference space" : "Using LOCAL reference space");
    return true;
}

XrPath OpenXrApp::path(const char* text) {
    XrPath result = XR_NULL_PATH;
    if (XR_FAILED(xrStringToPath(instance_, text, &result))) return XR_NULL_PATH;
    return result;
}

bool OpenXrApp::suggestControllerBindings(const char* profilePath) {
    const XrPath profile = path(profilePath);
    if (profile == XR_NULL_PATH) return false;

    const std::array<XrActionSuggestedBinding, 10> bindings{{
        {grip_pose_action_, path("/user/hand/left/input/grip/pose")},
        {grip_pose_action_, path("/user/hand/right/input/grip/pose")},
        {trigger_action_, path("/user/hand/right/input/trigger/value")},
        {squeeze_action_, path("/user/hand/left/input/squeeze/value")},
        {squeeze_action_, path("/user/hand/right/input/squeeze/value")},
        {haptic_action_, path("/user/hand/left/output/haptic")},
        {haptic_action_, path("/user/hand/right/output/haptic")},
        {toggle_action_, path("/user/hand/right/input/a/click")},
        {reset_action_, path("/user/hand/right/input/b/click")},
        {reset_action_, path("/user/hand/right/input/menu/click")},
    }};
    std::vector<XrActionSuggestedBinding> valid;
    valid.reserve(bindings.size());
    for (const auto& binding : bindings)
        if (binding.binding != XR_NULL_PATH) valid.push_back(binding);

    XrInteractionProfileSuggestedBinding suggested{XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING};
    suggested.interactionProfile = profile;
    suggested.countSuggestedBindings = static_cast<uint32_t>(valid.size());
    suggested.suggestedBindings = valid.data();
    const XrResult result = xrSuggestInteractionProfileBindings(instance_, &suggested);
    if (XR_FAILED(result)) {
        std::ostringstream stream;
        stream << "binding profile rejected: " << profilePath << " result=" << static_cast<int>(result);
        logWarn(stream.str());
        return false;
    }
    logInfo(std::string("binding profile accepted: ") + profilePath);
    return true;
}

bool OpenXrApp::createActions() {
    hand_paths_[kLeft] = path("/user/hand/left");
    hand_paths_[kRight] = path("/user/hand/right");
    if (hand_paths_[kLeft] == XR_NULL_PATH || hand_paths_[kRight] == XR_NULL_PATH)
        return fail("unable to create OpenXR hand paths");

    XrActionSetCreateInfo setInfo{XR_TYPE_ACTION_SET_CREATE_INFO};
    copyName(setInfo.actionSetName, XR_MAX_ACTION_SET_NAME_SIZE, "fourd");
    copyName(setInfo.localizedActionSetName, XR_MAX_LOCALIZED_ACTION_SET_NAME_SIZE, "4D interaction");
    setInfo.priority = 0;
    if (!check(xrCreateActionSet(instance_, &setInfo, &action_set_), "xrCreateActionSet")) return false;

    auto createAction = [&](XrActionType type, const char* name, const char* localized,
                            uint32_t subactionCount, const XrPath* subactions, XrAction* output) {
        XrActionCreateInfo info{XR_TYPE_ACTION_CREATE_INFO};
        info.actionType = type;
        copyName(info.actionName, XR_MAX_ACTION_NAME_SIZE, name);
        copyName(info.localizedActionName, XR_MAX_LOCALIZED_ACTION_NAME_SIZE, localized);
        info.countSubactionPaths = subactionCount;
        info.subactionPaths = subactions;
        return check(xrCreateAction(action_set_, &info, output), name);
    };

    if (!createAction(XR_ACTION_TYPE_POSE_INPUT, "grip_pose", "Grip pose", 2,
                      hand_paths_.data(), &grip_pose_action_)) return false;
    if (!createAction(XR_ACTION_TYPE_FLOAT_INPUT, "trigger", "Trigger", 2,
                      hand_paths_.data(), &trigger_action_)) return false;
    if (!createAction(XR_ACTION_TYPE_FLOAT_INPUT, "squeeze", "Squeeze", 2,
                      hand_paths_.data(), &squeeze_action_)) return false;
    if (!createAction(XR_ACTION_TYPE_VIBRATION_OUTPUT, "haptic", "Haptic", 2,
                      hand_paths_.data(), &haptic_action_)) return false;
    if (!createAction(XR_ACTION_TYPE_BOOLEAN_INPUT, "projection_toggle", "Projection toggle", 0,
                      nullptr, &toggle_action_)) return false;
    if (!createAction(XR_ACTION_TYPE_BOOLEAN_INPUT, "reset", "Reset", 0,
                      nullptr, &reset_action_)) return false;

    bool anyProfile = false;
    if (support_bd_controller_)
        anyProfile |= suggestControllerBindings("/interaction_profiles/bytedance/pico4_controller");
    anyProfile |= suggestControllerBindings("/interaction_profiles/pico/neo3_controller");
    if (!anyProfile) logWarn("No PICO controller binding profile accepted at initialization");

    XrActionSpaceCreateInfo spaceInfo{XR_TYPE_ACTION_SPACE_CREATE_INFO};
    spaceInfo.action = grip_pose_action_;
    spaceInfo.poseInActionSpace.orientation.w = 1.0f;
    for (int hand = 0; hand < 2; ++hand) {
        spaceInfo.subactionPath = hand_paths_[hand];
        if (!check(xrCreateActionSpace(session_, &spaceInfo, &grip_spaces_[hand]), "xrCreateActionSpace"))
            return false;
    }

    XrSessionActionSetsAttachInfo attach{XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO};
    attach.countActionSets = 1;
    attach.actionSets = &action_set_;
    return check(xrAttachSessionActionSets(session_, &attach), "xrAttachSessionActionSets");
}

bool OpenXrApp::createSwapchains() {
    uint32_t viewCount = 0;
    if (!check(xrEnumerateViewConfigurationViews(instance_, system_id_,
               XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 0, &viewCount, nullptr),
               "xrEnumerateViewConfigurationViews(count)")) return false;
    if (viewCount == 0) return fail("runtime reported zero stereo views");

    config_views_.assign(viewCount, {XR_TYPE_VIEW_CONFIGURATION_VIEW});
    if (!check(xrEnumerateViewConfigurationViews(instance_, system_id_,
               XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, viewCount, &viewCount,
               config_views_.data()), "xrEnumerateViewConfigurationViews")) return false;
    xr_views_.assign(viewCount, {XR_TYPE_VIEW});

    uint32_t formatCount = 0;
    if (!check(xrEnumerateSwapchainFormats(session_, 0, &formatCount, nullptr),
               "xrEnumerateSwapchainFormats(count)")) return false;
    std::vector<int64_t> formats(formatCount);
    if (!check(xrEnumerateSwapchainFormats(session_, formatCount, &formatCount, formats.data()),
               "xrEnumerateSwapchainFormats")) return false;
    const std::array<int64_t, 2> preferred{{GL_RGBA8, GL_SRGB8_ALPHA8}};
    auto chosen = std::find_first_of(formats.begin(), formats.end(), preferred.begin(), preferred.end());
    if (chosen == formats.end()) return fail("runtime exposes no supported GLES RGBA swapchain format");
    swapchain_format_ = *chosen;

    swapchains_.clear();
    swapchains_.resize(viewCount);
    for (uint32_t i = 0; i < viewCount; ++i) {
        XrSwapchainCreateInfoFoveationFB foveationInfo{XR_TYPE_SWAPCHAIN_CREATE_INFO_FOVEATION_FB};
        if (support_foveation_)
            foveationInfo.flags = XR_SWAPCHAIN_CREATE_FOVEATION_SCALED_BIN_BIT_FB;

        XrSwapchainCreateInfo createInfo{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        createInfo.next = support_foveation_ ? &foveationInfo : nullptr;
        createInfo.usageFlags = XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
        createInfo.format = swapchain_format_;
        createInfo.sampleCount = 1;
        createInfo.width = config_views_[i].recommendedImageRectWidth;
        createInfo.height = config_views_[i].recommendedImageRectHeight;
        createInfo.faceCount = 1;
        createInfo.arraySize = 1;
        createInfo.mipCount = 1;
        if (!check(xrCreateSwapchain(session_, &createInfo, &swapchains_[i].handle), "xrCreateSwapchain"))
            return false;
        swapchains_[i].width = static_cast<int32_t>(createInfo.width);
        swapchains_[i].height = static_cast<int32_t>(createInfo.height);

        uint32_t imageCount = 0;
        if (!check(xrEnumerateSwapchainImages(swapchains_[i].handle, 0, &imageCount, nullptr),
                   "xrEnumerateSwapchainImages(count)")) return false;
        swapchains_[i].images.assign(imageCount, {XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_ES_KHR});
        if (!check(xrEnumerateSwapchainImages(
                       swapchains_[i].handle, imageCount, &imageCount,
                       reinterpret_cast<XrSwapchainImageBaseHeader*>(swapchains_[i].images.data())),
                   "xrEnumerateSwapchainImages")) return false;
    }
    return true;
}

void OpenXrApp::configureRefreshRate() {
    if (!support_refresh_rate_) return;
    xrGetInstanceProcAddr(instance_, "xrEnumerateDisplayRefreshRatesFB",
                          reinterpret_cast<PFN_xrVoidFunction*>(&enumerate_refresh_rates_));
    xrGetInstanceProcAddr(instance_, "xrGetDisplayRefreshRateFB",
                          reinterpret_cast<PFN_xrVoidFunction*>(&get_refresh_rate_));
    xrGetInstanceProcAddr(instance_, "xrRequestDisplayRefreshRateFB",
                          reinterpret_cast<PFN_xrVoidFunction*>(&request_refresh_rate_));
    if (!enumerate_refresh_rates_ || !request_refresh_rate_) {
        logWarn("XR_FB_display_refresh_rate advertised but functions unavailable");
        support_refresh_rate_ = false;
        return;
    }

    uint32_t count = 0;
    if (XR_FAILED(enumerate_refresh_rates_(session_, 0, &count, nullptr)) || count == 0) return;
    std::vector<float> rates(count);
    if (XR_FAILED(enumerate_refresh_rates_(session_, count, &count, rates.data()))) return;
    float selected = *std::max_element(rates.begin(), rates.end());
    for (float rate : rates) if (std::abs(rate - 90.0f) < 0.5f) selected = rate;
    const XrResult result = request_refresh_rate_(session_, selected);
    std::ostringstream stream;
    stream << "display refresh request " << selected << " Hz result=" << static_cast<int>(result);
    logInfo(stream.str());
}

void OpenXrApp::initializePassthrough() {
    if (!support_passthrough_) return;
    xrGetInstanceProcAddr(instance_, "xrCreatePassthroughFB", reinterpret_cast<PFN_xrVoidFunction*>(&create_passthrough_));
    xrGetInstanceProcAddr(instance_, "xrDestroyPassthroughFB", reinterpret_cast<PFN_xrVoidFunction*>(&destroy_passthrough_));
    xrGetInstanceProcAddr(instance_, "xrPassthroughStartFB", reinterpret_cast<PFN_xrVoidFunction*>(&start_passthrough_));
    xrGetInstanceProcAddr(instance_, "xrCreatePassthroughLayerFB", reinterpret_cast<PFN_xrVoidFunction*>(&create_passthrough_layer_));
    xrGetInstanceProcAddr(instance_, "xrDestroyPassthroughLayerFB", reinterpret_cast<PFN_xrVoidFunction*>(&destroy_passthrough_layer_));
    xrGetInstanceProcAddr(instance_, "xrPassthroughLayerResumeFB", reinterpret_cast<PFN_xrVoidFunction*>(&resume_passthrough_layer_));
    if (!create_passthrough_ || !create_passthrough_layer_ || !resume_passthrough_layer_) {
        logWarn("XR_FB_passthrough advertised but required functions unavailable");
        support_passthrough_ = false;
        return;
    }

    XrPassthroughCreateInfoFB createInfo{XR_TYPE_PASSTHROUGH_CREATE_INFO_FB};
    createInfo.flags = XR_PASSTHROUGH_IS_RUNNING_AT_CREATION_BIT_FB;
    if (XR_FAILED(create_passthrough_(session_, &createInfo, &passthrough_))) return;
    XrPassthroughLayerCreateInfoFB layerInfo{XR_TYPE_PASSTHROUGH_LAYER_CREATE_INFO_FB};
    layerInfo.passthrough = passthrough_;
    layerInfo.purpose = XR_PASSTHROUGH_LAYER_PURPOSE_RECONSTRUCTION_FB;
    if (XR_FAILED(create_passthrough_layer_(session_, &layerInfo, &passthrough_layer_))) return;
    if (start_passthrough_) start_passthrough_(passthrough_);
    if (XR_SUCCEEDED(resume_passthrough_layer_(passthrough_layer_))) {
        passthrough_active_ = true;
        logInfo("passthrough active");
    }
}

void OpenXrApp::initializeHandTracking() {
    if (!support_hand_tracking_) return;
    xrGetInstanceProcAddr(instance_, "xrCreateHandTrackerEXT", reinterpret_cast<PFN_xrVoidFunction*>(&create_hand_tracker_));
    xrGetInstanceProcAddr(instance_, "xrDestroyHandTrackerEXT", reinterpret_cast<PFN_xrVoidFunction*>(&destroy_hand_tracker_));
    xrGetInstanceProcAddr(instance_, "xrLocateHandJointsEXT", reinterpret_cast<PFN_xrVoidFunction*>(&locate_hand_joints_));
    if (!create_hand_tracker_ || !locate_hand_joints_) {
        support_hand_tracking_ = false;
        logWarn("XR_EXT_hand_tracking advertised but functions unavailable");
        return;
    }
    for (int hand = 0; hand < 2; ++hand) {
        XrHandTrackerCreateInfoEXT info{XR_TYPE_HAND_TRACKER_CREATE_INFO_EXT};
        info.hand = hand == kLeft ? XR_HAND_LEFT_EXT : XR_HAND_RIGHT_EXT;
        info.handJointSet = XR_HAND_JOINT_SET_DEFAULT_EXT;
        if (XR_FAILED(create_hand_tracker_(session_, &info, &hand_trackers_[hand]))) {
            hand_trackers_[hand] = XR_NULL_HANDLE;
        }
    }
    logInfo("hand tracking capability initialized");
}

void OpenXrApp::initializeFoveation() {
    if (!support_foveation_) return;
    xrGetInstanceProcAddr(instance_, "xrCreateFoveationProfileFB", reinterpret_cast<PFN_xrVoidFunction*>(&create_foveation_profile_));
    xrGetInstanceProcAddr(instance_, "xrDestroyFoveationProfileFB", reinterpret_cast<PFN_xrVoidFunction*>(&destroy_foveation_profile_));
    xrGetInstanceProcAddr(instance_, "xrUpdateSwapchainFB", reinterpret_cast<PFN_xrVoidFunction*>(&update_swapchain_));
    if (!create_foveation_profile_ || !update_swapchain_) {
        support_foveation_ = false;
        logWarn("foveation extensions advertised but required functions unavailable");
        return;
    }

    XrFoveationLevelProfileCreateInfoFB levelInfo{XR_TYPE_FOVEATION_LEVEL_PROFILE_CREATE_INFO_FB};
    levelInfo.level = XR_FOVEATION_LEVEL_MEDIUM_FB;
    levelInfo.verticalOffset = 0.0f;
    levelInfo.dynamic = XR_FOVEATION_DYNAMIC_DISABLED_FB;
    XrFoveationProfileCreateInfoFB profileInfo{XR_TYPE_FOVEATION_PROFILE_CREATE_INFO_FB};
    profileInfo.next = &levelInfo;
    if (XR_FAILED(create_foveation_profile_(session_, &profileInfo, &foveation_profile_))) return;

    bool allApplied = true;
    for (const Swapchain& swapchain : swapchains_) {
        XrSwapchainStateFoveationFB state{XR_TYPE_SWAPCHAIN_STATE_FOVEATION_FB};
        state.profile = foveation_profile_;
        const XrResult result = update_swapchain_(
            swapchain.handle, reinterpret_cast<const XrSwapchainStateBaseHeaderFB*>(&state));
        allApplied = allApplied && XR_SUCCEEDED(result);
    }
    foveation_active_ = allApplied;
    logInfo(allApplied ? "fixed foveation MEDIUM active" : "fixed foveation profile partially rejected");
}

bool OpenXrApp::initializeOptionalFeatures() {
    configureRefreshRate();
    initializePassthrough();
    initializeHandTracking();
    initializeFoveation();
    return true;
}

void OpenXrApp::locateHands(XrTime displayTime) {
    for (int hand = 0; hand < 2; ++hand) {
        const HandGestureState previous = hand_gestures_[hand];
        hand_gestures_[hand] = {};
        if (!support_hand_tracking_ || !locate_hand_joints_ ||
            hand_trackers_[hand] == XR_NULL_HANDLE) continue;

        std::array<XrHandJointLocationEXT, XR_HAND_JOINT_COUNT_EXT> joints{};
        XrHandJointLocationsEXT locations{XR_TYPE_HAND_JOINT_LOCATIONS_EXT};
        locations.jointCount = static_cast<uint32_t>(joints.size());
        locations.jointLocations = joints.data();
        XrHandJointsLocateInfoEXT info{XR_TYPE_HAND_JOINTS_LOCATE_INFO_EXT};
        info.baseSpace = app_space_;
        info.time = displayTime;
        if (XR_FAILED(locate_hand_joints_(hand_trackers_[hand], &info, &locations)) ||
            locations.isActive != XR_TRUE) continue;

        const std::array<XrHandJointEXT, 8> required{{
            XR_HAND_JOINT_PALM_EXT, XR_HAND_JOINT_WRIST_EXT,
            XR_HAND_JOINT_MIDDLE_METACARPAL_EXT, XR_HAND_JOINT_THUMB_TIP_EXT,
            XR_HAND_JOINT_INDEX_TIP_EXT, XR_HAND_JOINT_MIDDLE_TIP_EXT,
            XR_HAND_JOINT_RING_TIP_EXT, XR_HAND_JOINT_LITTLE_TIP_EXT,
        }};
        bool valid = true;
        for (const XrHandJointEXT joint : required) {
            valid = valid && ((joints[joint].locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT) != 0);
        }
        if (!valid) continue;

        HandGestureInput gesture;
        gesture.active = true;
        gesture.palm = toVec3(joints[XR_HAND_JOINT_PALM_EXT].pose.position);
        gesture.wrist = toVec3(joints[XR_HAND_JOINT_WRIST_EXT].pose.position);
        gesture.middleMetacarpal = toVec3(joints[XR_HAND_JOINT_MIDDLE_METACARPAL_EXT].pose.position);
        gesture.thumbTip = toVec3(joints[XR_HAND_JOINT_THUMB_TIP_EXT].pose.position);
        gesture.indexTip = toVec3(joints[XR_HAND_JOINT_INDEX_TIP_EXT].pose.position);
        gesture.middleTip = toVec3(joints[XR_HAND_JOINT_MIDDLE_TIP_EXT].pose.position);
        gesture.ringTip = toVec3(joints[XR_HAND_JOINT_RING_TIP_EXT].pose.position);
        gesture.littleTip = toVec3(joints[XR_HAND_JOINT_LITTLE_TIP_EXT].pose.position);
        hand_gestures_[hand] = evaluateHandGesture(gesture, previous);
    }
}

bool OpenXrApp::initialize() {
    last_error_.clear();
    if (!app_ || !app_->activity) return fail("android_app/activity is null");
    if (!initializeLoader()) return false;
    if (!enumerateExtensions()) return false;
    if (!createInstance()) return false;
    if (!createSystem()) return false;
    if (!createSession()) return false;
    if (!createReferenceSpace()) return false;
    if (!createActions()) return false;
    if (!createSwapchains()) return false;
    if (!initializeOptionalFeatures()) return false;

    std::ostringstream stream;
    stream << "integration initialized: views=" << swapchains_.size()
           << " bd_controller=" << support_bd_controller_
           << " refresh=" << support_refresh_rate_
           << " passthrough=" << passthrough_active_
           << " hands=" << support_hand_tracking_
           << " foveation=" << foveation_active_;
    logInfo(stream.str());
    return true;
}

void OpenXrApp::handleSessionState(XrSessionState state) {
    session_state_ = state;
    if (state == XR_SESSION_STATE_READY && !session_running_) {
        XrSessionBeginInfo begin{XR_TYPE_SESSION_BEGIN_INFO};
        begin.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
        if (XR_SUCCEEDED(xrBeginSession(session_, &begin))) {
            session_running_ = true;
            logInfo("OpenXR session running");
        }
    } else if (state == XR_SESSION_STATE_STOPPING && session_running_) {
        xrEndSession(session_);
        session_running_ = false;
        trigger_tracker_.reset();
        left_squeeze_tracker_.reset();
        right_squeeze_tracker_.reset();
        interaction_.cancel();
    } else if (state == XR_SESSION_STATE_EXITING || state == XR_SESSION_STATE_LOSS_PENDING) {
        exit_requested_ = true;
    }
}

void OpenXrApp::pollEvents() {
    if (instance_ == XR_NULL_HANDLE) return;
    while (true) {
        XrEventDataBuffer event{XR_TYPE_EVENT_DATA_BUFFER};
        const XrResult result = xrPollEvent(instance_, &event);
        if (result == XR_EVENT_UNAVAILABLE) break;
        if (XR_FAILED(result)) {
            fail("xrPollEvent failed");
            exit_requested_ = true;
            break;
        }
        switch (event.type) {
            case XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED: {
                const auto* changed = reinterpret_cast<const XrEventDataSessionStateChanged*>(&event);
                handleSessionState(changed->state);
                break;
            }
            case XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING:
                exit_requested_ = true;
                break;
            default:
                break;
        }
    }
}

void OpenXrApp::applyHaptic(XrPath handPath, float amplitude, XrDuration duration) {
    if (session_ == XR_NULL_HANDLE || haptic_action_ == XR_NULL_HANDLE) return;
    XrHapticVibration vibration{XR_TYPE_HAPTIC_VIBRATION};
    vibration.amplitude = std::max(0.0f, std::min(1.0f, amplitude));
    vibration.duration = duration;
    vibration.frequency = XR_FREQUENCY_UNSPECIFIED;
    XrHapticActionInfo info{XR_TYPE_HAPTIC_ACTION_INFO};
    info.action = haptic_action_;
    info.subactionPath = handPath;
    xrApplyHapticFeedback(session_, &info, reinterpret_cast<const XrHapticBaseHeader*>(&vibration));
}

bool OpenXrApp::updateInteraction(XrTime displayTime) {
    XrActiveActionSet active{action_set_, XR_NULL_PATH};
    XrActionsSyncInfo sync{XR_TYPE_ACTIONS_SYNC_INFO};
    sync.countActiveActionSets = 1;
    sync.activeActionSets = &active;
    if (!check(xrSyncActions(session_, &sync), "xrSyncActions")) return false;

    auto readFloat = [&](XrAction action, XrPath subaction) {
        XrActionStateGetInfo info{XR_TYPE_ACTION_STATE_GET_INFO};
        info.action = action;
        info.subactionPath = subaction;
        XrActionStateFloat state{XR_TYPE_ACTION_STATE_FLOAT};
        if (XR_FAILED(xrGetActionStateFloat(session_, &info, &state)) || !state.isActive) return 0.0f;
        return state.currentState;
    };
    auto readBool = [&](XrAction action) {
        XrActionStateGetInfo info{XR_TYPE_ACTION_STATE_GET_INFO};
        info.action = action;
        XrActionStateBoolean state{XR_TYPE_ACTION_STATE_BOOLEAN};
        if (XR_FAILED(xrGetActionStateBoolean(session_, &info, &state)) || !state.isActive) return false;
        return state.currentState == XR_TRUE;
    };

    std::array<XrSpaceLocation, 2> locations{{
        {XR_TYPE_SPACE_LOCATION}, {XR_TYPE_SPACE_LOCATION}
    }};
    std::array<bool, 2> poseValid{{false, false}};
    for (int hand = 0; hand < 2; ++hand) {
        if (grip_spaces_[hand] == XR_NULL_HANDLE) continue;
        if (XR_SUCCEEDED(xrLocateSpace(grip_spaces_[hand], app_space_, displayTime, &locations[hand])))
            poseValid[hand] = validPose(locations[hand]);
    }

    locateHands(displayTime);
    std::array<Vec3, 2> effectivePosition{{Vec3{}, Vec3{}}};
    std::array<bool, 2> effectivePoseValid = poseValid;
    for (int hand = 0; hand < 2; ++hand) {
        if (poseValid[hand]) {
            effectivePosition[hand] = toVec3(locations[hand].pose.position);
        } else if (hand_gestures_[hand].active) {
            effectivePoseValid[hand] = true;
            effectivePosition[hand] = hand_gestures_[hand].position;
        }
    }

    const bool rightControllerActive = poseValid[kRight];
    const bool leftControllerActive = poseValid[kLeft];
    const bool triggerPressed = rightControllerActive
        ? readFloat(trigger_action_, hand_paths_[kRight]) > kPressThreshold
        : hand_gestures_[kRight].active && hand_gestures_[kRight].pinch;
    const bool rightSqueeze = rightControllerActive
        ? readFloat(squeeze_action_, hand_paths_[kRight]) > kPressThreshold
        : hand_gestures_[kRight].active && hand_gestures_[kRight].squeeze;
    const bool leftSqueeze = leftControllerActive
        ? readFloat(squeeze_action_, hand_paths_[kLeft]) > kPressThreshold
        : hand_gestures_[kLeft].active && hand_gestures_[kLeft].squeeze;

    const bool trackingLostWhileActive =
        (!effectivePoseValid[kRight] && (trigger_tracker_.previous || right_squeeze_tracker_.previous)) ||
        (!effectivePoseValid[kLeft] && left_squeeze_tracker_.previous);

    FrameInput frame;
    frame.rightControllerPosition = effectivePosition[kRight];
    frame.leftControllerPosition = effectivePosition[kLeft];
    frame.trackballCenter = interaction_.translation();
    frame.trigger = trigger_tracker_.sample(triggerPressed);
    frame.rightSqueeze = right_squeeze_tracker_.sample(rightSqueeze);
    frame.leftSqueeze = left_squeeze_tracker_.sample(leftSqueeze);
    const ButtonFrame toggle = toggle_tracker_.sample(readBool(toggle_action_));
    const ButtonFrame reset = reset_tracker_.sample(readBool(reset_action_));
    frame.projectionToggleCommand = toggle.down;
    frame.resetCommand = reset.down;
    frame.cancelManipulations = trackingLostWhileActive;

    interaction_.update(frame);
    if (frame.trigger.down && rightControllerActive)
        applyHaptic(hand_paths_[kRight], 0.25f, 25000000);
    if ((toggle.down || reset.down) && rightControllerActive)
        applyHaptic(hand_paths_[kRight], 0.45f, 35000000);
    return true;
}

bool OpenXrApp::renderProjectionLayer(
    XrTime displayTime,
    XrCompositionLayerProjection* layer,
    std::vector<XrCompositionLayerProjectionView>* layerViews) {
    XrViewLocateInfo locate{XR_TYPE_VIEW_LOCATE_INFO};
    locate.viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
    locate.displayTime = displayTime;
    locate.space = app_space_;
    XrViewState viewState{XR_TYPE_VIEW_STATE};
    uint32_t outputCount = 0;
    if (!check(xrLocateViews(session_, &locate, &viewState,
                             static_cast<uint32_t>(xr_views_.size()), &outputCount,
                             xr_views_.data()), "xrLocateViews")) return false;
    constexpr XrViewStateFlags required = XR_VIEW_STATE_POSITION_VALID_BIT | XR_VIEW_STATE_ORIENTATION_VALID_BIT;
    if ((viewState.viewStateFlags & required) != required || outputCount != swapchains_.size()) return false;

    const RenderPacket packet = makeRenderPacket(tesseract_, interaction_, projection_);
    if (!packet.valid) return fail("render packet became invalid");
    layerViews->assign(outputCount, {XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW});

    for (uint32_t i = 0; i < outputCount; ++i) {
        Swapchain& swapchain = swapchains_[i];
        uint32_t imageIndex = 0;
        XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
        if (!check(xrAcquireSwapchainImage(swapchain.handle, &acquire, &imageIndex),
                   "xrAcquireSwapchainImage")) return false;
        XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
        wait.timeout = XR_INFINITE_DURATION;
        if (!check(xrWaitSwapchainImage(swapchain.handle, &wait), "xrWaitSwapchainImage")) return false;

        std::string renderError;
        const bool rendered = imageIndex < swapchain.images.size() &&
            renderer_.render(swapchain.images[imageIndex].image,
                             swapchain.width, swapchain.height,
                             xr_views_[i].pose, xr_views_[i].fov,
                             packet, passthrough_active_, &renderError);
        XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
        const XrResult releaseResult = xrReleaseSwapchainImage(swapchain.handle, &release);
        if (!rendered) return fail("GLES render failed: " + renderError);
        if (!check(releaseResult, "xrReleaseSwapchainImage")) return false;

        auto& projectionView = (*layerViews)[i];
        projectionView.pose = xr_views_[i].pose;
        projectionView.fov = xr_views_[i].fov;
        projectionView.subImage.swapchain = swapchain.handle;
        projectionView.subImage.imageRect.offset = {0, 0};
        projectionView.subImage.imageRect.extent = {swapchain.width, swapchain.height};
        projectionView.subImage.imageArrayIndex = 0;
    }

    layer->space = app_space_;
    layer->viewCount = static_cast<uint32_t>(layerViews->size());
    layer->views = layerViews->data();
    layer->layerFlags = passthrough_active_ ? XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT : 0;
    return true;
}

bool OpenXrApp::renderFrame() {
    if (!session_running_) return true;
    XrFrameWaitInfo wait{XR_TYPE_FRAME_WAIT_INFO};
    XrFrameState frameState{XR_TYPE_FRAME_STATE};
    if (!check(xrWaitFrame(session_, &wait, &frameState), "xrWaitFrame")) return false;
    XrFrameBeginInfo begin{XR_TYPE_FRAME_BEGIN_INFO};
    if (!check(xrBeginFrame(session_, &begin), "xrBeginFrame")) return false;

    bool ok = updateInteraction(frameState.predictedDisplayTime);
    std::vector<const XrCompositionLayerBaseHeader*> layers;
    XrCompositionLayerPassthroughFB passthroughLayer{XR_TYPE_COMPOSITION_LAYER_PASSTHROUGH_FB};
    if (passthrough_active_ && passthrough_layer_ != XR_NULL_HANDLE) {
        passthroughLayer.layerHandle = passthrough_layer_;
        passthroughLayer.flags = XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
        passthroughLayer.space = XR_NULL_HANDLE;
        layers.push_back(reinterpret_cast<const XrCompositionLayerBaseHeader*>(&passthroughLayer));
    }

    XrCompositionLayerProjection projectionLayer{XR_TYPE_COMPOSITION_LAYER_PROJECTION};
    std::vector<XrCompositionLayerProjectionView> projectionViews;
    if (ok && frameState.shouldRender == XR_TRUE &&
        renderProjectionLayer(frameState.predictedDisplayTime, &projectionLayer, &projectionViews)) {
        layers.push_back(reinterpret_cast<const XrCompositionLayerBaseHeader*>(&projectionLayer));
    }

    XrFrameEndInfo end{XR_TYPE_FRAME_END_INFO};
    end.displayTime = frameState.predictedDisplayTime;
    end.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
    end.layerCount = static_cast<uint32_t>(layers.size());
    end.layers = layers.data();
    const XrResult endResult = xrEndFrame(session_, &end);
    if (!ok) return false;
    return check(endResult, "xrEndFrame");
}

void OpenXrApp::shutdown() {
    if (session_running_ && session_ != XR_NULL_HANDLE) {
        xrEndSession(session_);
        session_running_ = false;
    }
    for (auto& tracker : hand_trackers_) {
        if (tracker != XR_NULL_HANDLE && destroy_hand_tracker_) destroy_hand_tracker_(tracker);
        tracker = XR_NULL_HANDLE;
    }
    if (foveation_profile_ != XR_NULL_HANDLE && destroy_foveation_profile_)
        destroy_foveation_profile_(foveation_profile_);
    foveation_profile_ = XR_NULL_HANDLE;
    foveation_active_ = false;

    if (passthrough_layer_ != XR_NULL_HANDLE && destroy_passthrough_layer_)
        destroy_passthrough_layer_(passthrough_layer_);
    passthrough_layer_ = XR_NULL_HANDLE;
    if (passthrough_ != XR_NULL_HANDLE && destroy_passthrough_)
        destroy_passthrough_(passthrough_);
    passthrough_ = XR_NULL_HANDLE;
    passthrough_active_ = false;

    for (Swapchain& swapchain : swapchains_) {
        if (swapchain.handle != XR_NULL_HANDLE) xrDestroySwapchain(swapchain.handle);
        swapchain.handle = XR_NULL_HANDLE;
        swapchain.images.clear();
    }
    swapchains_.clear();
    for (auto& space : grip_spaces_) {
        if (space != XR_NULL_HANDLE) xrDestroySpace(space);
        space = XR_NULL_HANDLE;
    }
    if (app_space_ != XR_NULL_HANDLE) xrDestroySpace(app_space_);
    app_space_ = XR_NULL_HANDLE;
    if (action_set_ != XR_NULL_HANDLE) xrDestroyActionSet(action_set_);
    action_set_ = XR_NULL_HANDLE;
    if (session_ != XR_NULL_HANDLE) xrDestroySession(session_);
    session_ = XR_NULL_HANDLE;
    renderer_.shutdown();
    if (instance_ != XR_NULL_HANDLE) xrDestroyInstance(instance_);
    instance_ = XR_NULL_HANDLE;
    system_id_ = XR_NULL_SYSTEM_ID;
}

}  // namespace fourd::android
