#include "gles_renderer.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <sstream>

namespace fourd::android {
namespace {

struct GlVertex {
    float x, y, z;
    float r, g, b, a;
};

void setError(std::string* error, const std::string& message) {
    if (error) *error = message;
}

std::string eglError(const char* where) {
    std::ostringstream stream;
    stream << where << " failed, EGL error=0x" << std::hex << eglGetError();
    return stream.str();
}

float clamp01(float v) { return std::max(0.0f, std::min(1.0f, v)); }

}  // namespace

Mat4f Mat4f::identity() {
    Mat4f out;
    out.v[0] = out.v[5] = out.v[10] = out.v[15] = 1.0f;
    return out;
}
Mat4f multiply(const Mat4f& a, const Mat4f& b) {
    Mat4f out;
    for (int col = 0; col < 4; ++col) {
        for (int row = 0; row < 4; ++row) {
            float sum = 0.0f;
            for (int k = 0; k < 4; ++k)
                sum += a.v[k * 4 + row] * b.v[col * 4 + k];
            out.v[col * 4 + row] = sum;
        }
    }
    return out;
}

Mat4f projectionFromFov(const XrFovf& fov, float nearZ, float farZ) {
    const float l = std::tan(fov.angleLeft);
    const float r = std::tan(fov.angleRight);
    const float d = std::tan(fov.angleDown);
    const float u = std::tan(fov.angleUp);
    Mat4f out{};
    out.v[0] = 2.0f / (r - l);
    out.v[5] = 2.0f / (u - d);
    out.v[8] = (r + l) / (r - l);
    out.v[9] = (u + d) / (u - d);
    out.v[10] = -(farZ + nearZ) / (farZ - nearZ);
    out.v[11] = -1.0f;
    out.v[14] = -(2.0f * farZ * nearZ) / (farZ - nearZ);
    return out;
}
Mat4f viewFromPose(const XrPosef& pose) {
    const float x = pose.orientation.x;
    const float y = pose.orientation.y;
    const float z = pose.orientation.z;
    const float w = pose.orientation.w;

    const float r00 = 1.0f - 2.0f * (y*y + z*z);
    const float r01 = 2.0f * (x*y - z*w);
    const float r02 = 2.0f * (x*z + y*w);
    const float r10 = 2.0f * (x*y + z*w);
    const float r11 = 1.0f - 2.0f * (x*x + z*z);
    const float r12 = 2.0f * (y*z - x*w);
    const float r20 = 2.0f * (x*z - y*w);
    const float r21 = 2.0f * (y*z + x*w);
    const float r22 = 1.0f - 2.0f * (x*x + y*y);

    Mat4f out = Mat4f::identity();
    out.v[0] = r00; out.v[4] = r10; out.v[8] = r20;
    out.v[1] = r01; out.v[5] = r11; out.v[9] = r21;
    out.v[2] = r02; out.v[6] = r12; out.v[10] = r22;

    const float px = pose.position.x;
    const float py = pose.position.y;
    const float pz = pose.position.z;
    out.v[12] = -(r00*px + r10*py + r20*pz);
    out.v[13] = -(r01*px + r11*py + r21*pz);
    out.v[14] = -(r02*px + r12*py + r22*pz);
    return out;
}

GlesRenderer::~GlesRenderer() { shutdown(); }
bool GlesRenderer::createContext(std::string* error) {
    display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display_ == EGL_NO_DISPLAY) { setError(error, eglError("eglGetDisplay")); return false; }
    if (!eglInitialize(display_, nullptr, nullptr)) { setError(error, eglError("eglInitialize")); return false; }

    const EGLint attrs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 0, EGL_NONE
    };
    EGLint count = 0;
    if (!eglChooseConfig(display_, attrs, &config_, 1, &count) || count < 1) {
        setError(error, eglError("eglChooseConfig")); return false;
    }
    const EGLint surfaceAttrs[] = {EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE};
    surface_ = eglCreatePbufferSurface(display_, config_, surfaceAttrs);
    if (surface_ == EGL_NO_SURFACE) { setError(error, eglError("eglCreatePbufferSurface")); return false; }

    const EGLint contextAttrs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context_ = eglCreateContext(display_, config_, EGL_NO_CONTEXT, contextAttrs);
    if (context_ == EGL_NO_CONTEXT) { setError(error, eglError("eglCreateContext")); return false; }
    if (!eglMakeCurrent(display_, surface_, surface_, context_)) {
        setError(error, eglError("eglMakeCurrent")); return false;
    }
    binding_.display = display_;
    binding_.config = config_;
    binding_.context = context_;
    return true;
}
GLuint GlesRenderer::compileShader(GLenum type, const char* source, std::string* error) {
    const GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    GLint compiled = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    if (compiled == GL_TRUE) return shader;

    GLint length = 0;
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &length);
    std::vector<char> log(static_cast<std::size_t>(std::max(length, 1)));
    glGetShaderInfoLog(shader, length, nullptr, log.data());
    setError(error, std::string("shader compile failed: ") + log.data());
    glDeleteShader(shader);
    return 0;
}

bool GlesRenderer::createProgram(std::string* error) {
    static const char* vertexSource = R"GLSL(#version 300 es
layout(location=0) in vec3 aPosition;
layout(location=1) in vec4 aColor;
uniform mat4 uMvp;
out vec4 vColor;
void main() { gl_Position = uMvp * vec4(aPosition, 1.0); vColor = aColor; }
)GLSL";
    static const char* fragmentSource = R"GLSL(#version 300 es
precision mediump float;
in vec4 vColor;
out vec4 fragColor;
void main() { fragColor = vColor; }
)GLSL";

    const GLuint vs = compileShader(GL_VERTEX_SHADER, vertexSource, error);
    if (!vs) return false;
    const GLuint fs = compileShader(GL_FRAGMENT_SHADER, fragmentSource, error);
    if (!fs) { glDeleteShader(vs); return false; }
    program_ = glCreateProgram();
    glAttachShader(program_, vs);
    glAttachShader(program_, fs);
    glLinkProgram(program_);
    glDeleteShader(vs);
    glDeleteShader(fs);

    GLint linked = GL_FALSE;
    glGetProgramiv(program_, GL_LINK_STATUS, &linked);
    if (linked != GL_TRUE) {
        GLint length = 0;
        glGetProgramiv(program_, GL_INFO_LOG_LENGTH, &length);
        std::vector<char> log(static_cast<std::size_t>(std::max(length, 1)));
        glGetProgramInfoLog(program_, length, nullptr, log.data());
        setError(error, std::string("program link failed: ") + log.data());
        glDeleteProgram(program_);
        program_ = 0;
        return false;
    }

    mvp_location_ = glGetUniformLocation(program_, "uMvp");
    glGenVertexArrays(1, &vao_);
    glGenBuffers(1, &vbo_);
    glGenFramebuffers(1, &framebuffer_);
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(GlVertex), reinterpret_cast<void*>(0));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, sizeof(GlVertex), reinterpret_cast<void*>(3 * sizeof(float)));
    glBindVertexArray(0);
    return glGetError() == GL_NO_ERROR;
}
bool GlesRenderer::initialize(XrInstance instance, XrSystemId systemId, std::string* error) {
    shutdown();
    if (!createContext(error)) { shutdown(); return false; }

    PFN_xrGetOpenGLESGraphicsRequirementsKHR getRequirements = nullptr;
    const XrResult getProc = xrGetInstanceProcAddr(
        instance, "xrGetOpenGLESGraphicsRequirementsKHR",
        reinterpret_cast<PFN_xrVoidFunction*>(&getRequirements));
    if (XR_FAILED(getProc) || !getRequirements) {
        setError(error, "xrGetOpenGLESGraphicsRequirementsKHR unavailable");
        shutdown();
        return false;
    }
    XrGraphicsRequirementsOpenGLESKHR requirements{XR_TYPE_GRAPHICS_REQUIREMENTS_OPENGL_ES_KHR};
    const XrResult reqResult = getRequirements(instance, systemId, &requirements);
    if (XR_FAILED(reqResult)) {
        setError(error, "xrGetOpenGLESGraphicsRequirementsKHR failed");
        shutdown();
        return false;
    }

    GLint major = 0, minor = 0;
    glGetIntegerv(GL_MAJOR_VERSION, &major);
    glGetIntegerv(GL_MINOR_VERSION, &minor);
    const XrVersion current = XR_MAKE_VERSION(static_cast<uint32_t>(major), static_cast<uint32_t>(minor), 0);
    if (current < requirements.minApiVersionSupported || current > requirements.maxApiVersionSupported) {
        setError(error, "created GLES context falls outside OpenXR runtime requirements");
        shutdown();
        return false;
    }
    if (!createProgram(error)) { shutdown(); return false; }
    return true;
}

void GlesRenderer::destroyGlObjects() {
    if (framebuffer_) glDeleteFramebuffers(1, &framebuffer_);
    if (vbo_) glDeleteBuffers(1, &vbo_);
    if (vao_) glDeleteVertexArrays(1, &vao_);
    if (program_) glDeleteProgram(program_);
    framebuffer_ = vbo_ = vao_ = program_ = 0;
    mvp_location_ = -1;
}
void GlesRenderer::shutdown() {
    if (display_ != EGL_NO_DISPLAY && context_ != EGL_NO_CONTEXT)
        eglMakeCurrent(display_, surface_, surface_, context_);
    destroyGlObjects();
    if (display_ != EGL_NO_DISPLAY) {
        eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context_ != EGL_NO_CONTEXT) eglDestroyContext(display_, context_);
        if (surface_ != EGL_NO_SURFACE) eglDestroySurface(display_, surface_);
        eglTerminate(display_);
    }
    display_ = EGL_NO_DISPLAY;
    config_ = nullptr;
    context_ = EGL_NO_CONTEXT;
    surface_ = EGL_NO_SURFACE;
    binding_ = {XR_TYPE_GRAPHICS_BINDING_OPENGL_ES_ANDROID_KHR};
}

bool GlesRenderer::render(GLuint colorTexture,
                          int32_t width,
                          int32_t height,
                          const XrPosef& eyePose,
                          const XrFovf& eyeFov,
                          const RenderPacket& packet,
                          bool transparentBackground,
                          std::string* error) {
    if (!valid() || !packet.valid || width <= 0 || height <= 0) {
        setError(error, "renderer called with invalid state or render packet");
        return false;
    }
    if (!eglMakeCurrent(display_, surface_, surface_, context_)) {
        setError(error, eglError("eglMakeCurrent(render)"));
        return false;
    }

    std::vector<GlVertex> vertices;
    vertices.reserve(Tesseract::kEdgeCount * 2);
    for (const Edge& edge : packet.edges) {
        for (int endpoint = 0; endpoint < 2; ++endpoint) {
            const std::size_t index = edge[endpoint];
            const Vec3& p = packet.projected_vertices[index];
            const float wColor = clamp01(0.5f + static_cast<float>(packet.transformed_w[index]) * 1.5f);
            vertices.push_back({static_cast<float>(p.x), static_cast<float>(p.y), static_cast<float>(p.z),
                                0.18f + 0.78f*wColor,
                                0.82f - 0.52f*wColor,
                                1.0f - 0.48f*wColor,
                                1.0f});
        }
    }

    const Mat4f projection = projectionFromFov(eyeFov, 0.05f, 50.0f);
    const Mat4f view = viewFromPose(eyePose);
    const Mat4f mvp = multiply(projection, view);

    glBindFramebuffer(GL_FRAMEBUFFER, framebuffer_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, colorTexture, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        setError(error, "OpenXR color texture produced incomplete GLES framebuffer");
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        return false;
    }
    glViewport(0, 0, width, height);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    if (transparentBackground) glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    else glClearColor(0.018f, 0.022f, 0.038f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(program_);
    glUniformMatrix4fv(mvp_location_, 1, GL_FALSE, mvp.v.data());
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER,
                 static_cast<GLsizeiptr>(vertices.size() * sizeof(GlVertex)),
                 vertices.data(), GL_STREAM_DRAW);
    glLineWidth(2.0f);
    glDrawArrays(GL_LINES, 0, static_cast<GLsizei>(vertices.size()));
    glBindVertexArray(0);
    glUseProgram(0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    const GLenum glError = glGetError();
    if (glError != GL_NO_ERROR) {
        std::ostringstream stream;
        stream << "GLES render error=0x" << std::hex << glError;
        setError(error, stream.str());
        return false;
    }
    return true;
}

}  // namespace fourd::android
