#include "hand_gesture.h"

#include <algorithm>
#include <cmath>

namespace fourd::android {
namespace {

double sanePositive(double value, double fallback) {
    return std::isfinite(value) && value > 0.0 ? value : fallback;
}

bool finiteAll(const HandGestureInput& input) {
    return isFinite(input.palm) && isFinite(input.wrist) &&
           isFinite(input.middleMetacarpal) && isFinite(input.thumbTip) &&
           isFinite(input.indexTip) && isFinite(input.middleTip) &&
           isFinite(input.ringTip) && isFinite(input.littleTip);
}

}  // namespace

HandGestureState evaluateHandGesture(const HandGestureInput& input,
                                     const HandGestureState& previous,
                                     HandGestureConfig config) {
    HandGestureState result;
    if (!input.active || !finiteAll(input)) return result;

    config.minimumHandScale = sanePositive(config.minimumHandScale, 0.04);
    config.pinchPressRatio = sanePositive(config.pinchPressRatio, 0.35);
    config.pinchReleaseRatio = std::max(config.pinchPressRatio,
        sanePositive(config.pinchReleaseRatio, 0.50));
    config.squeezePressRatio = sanePositive(config.squeezePressRatio, 1.00);
    config.squeezeReleaseRatio = std::max(config.squeezePressRatio,
        sanePositive(config.squeezeReleaseRatio, 1.25));

    const double measuredScale = length(input.middleMetacarpal - input.wrist);
    if (!std::isfinite(measuredScale) || measuredScale <= 1e-5) return result;
    const double scale = std::max(measuredScale, config.minimumHandScale);

    const double pinchDistance = length(input.thumbTip - input.indexTip);
    const double squeezeDistance = (
        length(input.middleTip - input.palm) +
        length(input.ringTip - input.palm) +
        length(input.littleTip - input.palm)) / 3.0;
    if (!std::isfinite(pinchDistance) || !std::isfinite(squeezeDistance)) return result;

    result.active = true;
    result.position = input.palm;
    result.handScale = scale;
    result.pinchRatio = pinchDistance / scale;
    result.squeezeRatio = squeezeDistance / scale;

    const bool keepPinch = previous.active && previous.pinch;
    const bool keepSqueeze = previous.active && previous.squeeze;
    result.pinch = keepPinch
        ? result.pinchRatio <= config.pinchReleaseRatio
        : result.pinchRatio <= config.pinchPressRatio;
    result.squeeze = keepSqueeze
        ? result.squeezeRatio <= config.squeezeReleaseRatio
        : result.squeezeRatio <= config.squeezePressRatio;
    return result;
}

}  // namespace fourd::android
