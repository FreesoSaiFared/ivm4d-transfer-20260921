#include "openxr_app.h"

#include <android/log.h>
#include <android_native_app_glue.h>

namespace {
constexpr const char* kTag = "4DForPico4";

void handleAppCommand(android_app* app, int32_t command) {
    auto* xr = static_cast<fourd::android::OpenXrApp*>(app->userData);
    if (!xr) return;
    switch (command) {
        case APP_CMD_RESUME:
            xr->onResume(true);
            break;
        case APP_CMD_PAUSE:
        case APP_CMD_STOP:
            xr->onResume(false);
            break;
        default:
            break;
    }
}
}  // namespace

void android_main(android_app* app) {
    fourd::android::OpenXrApp xr(app);
    app->userData = &xr;
    app->onAppCmd = handleAppCommand;

    if (!xr.initialize()) {
        __android_log_print(ANDROID_LOG_ERROR, kTag, "OpenXR initialization failed: %s", xr.lastError().c_str());
        ANativeActivity_finish(app->activity);
        return;
    }
    __android_log_print(ANDROID_LOG_INFO, kTag, "4D for PICO 4 native loop started");

    while (app->destroyRequested == 0 && !xr.shouldExit()) {
        for (;;) {
            int events = 0;
            android_poll_source* source = nullptr;
            const int timeoutMs = xr.sessionRunning() ? 0 : 10;
            const int pollResult = ALooper_pollOnce(timeoutMs, nullptr, &events,
                                                    reinterpret_cast<void**>(&source));
            if (pollResult < 0) break;
            if (source) source->process(app, source);
            if (app->destroyRequested != 0) break;
            if (timeoutMs != 0) break;
        }

        xr.pollEvents();
        if (xr.sessionRunning() && !xr.renderFrame()) {
            __android_log_print(ANDROID_LOG_ERROR, kTag, "frame failed: %s", xr.lastError().c_str());
            ANativeActivity_finish(app->activity);
            break;
        }
    }
    app->userData = nullptr;
    __android_log_print(ANDROID_LOG_INFO, kTag, "4D for PICO 4 native loop stopped");
}
