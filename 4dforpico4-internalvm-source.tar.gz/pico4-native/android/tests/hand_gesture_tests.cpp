#include "android/jni/hand_gesture.h"

#include <cmath>
#include <iostream>
#include <limits>
#include <string>

using fourd::Vec3;
using fourd::android::HandGestureInput;
using fourd::android::HandGestureState;
using fourd::android::evaluateHandGesture;

namespace {
int failures = 0;

void expect(bool condition, const std::string& name) {
    if (!condition) {
        ++failures;
        std::cerr << "FAIL: " << name << '\n';
    } else {
        std::cout << "PASS: " << name << '\n';
    }
}

HandGestureInput openHand() {
    HandGestureInput input;
    input.active = true;
    input.wrist = {0.0, 0.0, 0.0};
    input.middleMetacarpal = {0.0, 0.07, 0.0};
    input.palm = {0.0, 0.06, 0.0};
    input.thumbTip = {-0.04, 0.10, 0.0};
    input.indexTip = {0.04, 0.12, 0.0};
    input.middleTip = {0.0, 0.17, 0.0};
    input.ringTip = {0.02, 0.16, 0.0};
    input.littleTip = {0.035, 0.14, 0.0};
    return input;
}

}  // namespace

int main() {
    const HandGestureState inactive = evaluateHandGesture({});
    expect(!inactive.active && !inactive.pinch && !inactive.squeeze,
           "inactive input stays inactive");

    const HandGestureState open = evaluateHandGesture(openHand());
    expect(open.active, "open hand active");
    expect(!open.pinch, "open hand not pinching");
    expect(!open.squeeze, "open hand not squeezing");
    expect(std::abs(open.handScale - 0.07) < 1e-12, "hand scale normalized from wrist to metacarpal");
    expect(std::abs(open.position.y - 0.06) < 1e-12, "palm drives effective position");

    HandGestureInput pinchInput = openHand();
    pinchInput.thumbTip = {-0.0075, 0.11, 0.0};
    pinchInput.indexTip = {0.0075, 0.11, 0.0};
    const HandGestureState pinch = evaluateHandGesture(pinchInput);
    expect(pinch.pinch, "close thumb-index pinch presses trigger");
    expect(!pinch.squeeze, "pinch does not imply squeeze");

    HandGestureInput pinchBand = openHand();
    pinchBand.thumbTip = {-0.015, 0.11, 0.0};
    pinchBand.indexTip = {0.015, 0.11, 0.0};
    const HandGestureState pinchHeld = evaluateHandGesture(pinchBand, pinch);
    const HandGestureState pinchFresh = evaluateHandGesture(pinchBand, open);
    expect(pinchHeld.pinch, "pinch hysteresis holds inside release band");
    expect(!pinchFresh.pinch, "pinch hysteresis prevents fresh press inside release band");

    HandGestureInput closedInput = openHand();
    closedInput.middleTip = {0.0, 0.095, 0.0};
    closedInput.ringTip = {0.015, 0.09, 0.0};
    closedInput.littleTip = {0.02, 0.085, 0.0};
    const HandGestureState closed = evaluateHandGesture(closedInput);
    expect(closed.squeeze, "closed fingers press squeeze");

    HandGestureInput squeezeBand = openHand();
    squeezeBand.middleTip = {0.0, 0.135, 0.0};
    squeezeBand.ringTip = {0.015, 0.13, 0.0};
    squeezeBand.littleTip = {0.02, 0.125, 0.0};
    const HandGestureState squeezeHeld = evaluateHandGesture(squeezeBand, closed);
    const HandGestureState squeezeFresh = evaluateHandGesture(squeezeBand, open);
    expect(squeezeHeld.squeeze, "squeeze hysteresis holds inside release band");
    expect(!squeezeFresh.squeeze, "squeeze hysteresis prevents fresh press inside release band");

    HandGestureInput bad = openHand();
    bad.palm.x = std::numeric_limits<double>::quiet_NaN();
    const HandGestureState invalid = evaluateHandGesture(bad, closed);
    expect(!invalid.active && !invalid.pinch && !invalid.squeeze,
           "non-finite tracking sample cancels gesture state");

    if (failures != 0) {
        std::cerr << failures << " hand gesture test(s) failed\n";
        return 1;
    }
    std::cout << "HAND_GESTURE_TESTS_GREEN=14/14\n";
    return 0;
}
