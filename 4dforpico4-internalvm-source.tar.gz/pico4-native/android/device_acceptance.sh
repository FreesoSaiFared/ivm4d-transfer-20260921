#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ADB="${ANDROID_ADB:-/home/ned/.local/android/platform-tools/adb}"
APK="${PICO4_APK:-${ROOT}/build-apk/4d-for-pico4-debug.apk}"
PACKAGE="org.transductive.fourd.pico4"
ACTIVITY="android.app.NativeActivity"
EVIDENCE="${ROOT}/evidence/integration/device-runtime"
WAIT_SECONDS="${PICO4_DEVICE_WAIT_SECONDS:-12}"
SERIAL_OVERRIDE="${PICO4_SERIAL:-}"

mkdir -p "${EVIDENCE}"
SUMMARY="${EVIDENCE}/device-runtime-summary.txt"
DEVICES_LOG="${EVIDENCE}/adb-devices.txt"
INSTALL_LOG="${EVIDENCE}/adb-install.log"
START_LOG="${EVIDENCE}/adb-start.log"
LOGCAT="${EVIDENCE}/logcat.txt"
PROPS="${EVIDENCE}/device-properties.txt"
PACKAGE_LOG="${EVIDENCE}/package-info.txt"

fail() {
    printf 'DEVICE_ACCEPTANCE_FAIL=%s\n' "$1" | tee -a "${SUMMARY}" >&2
    exit 1
}

[[ -x "${ADB}" ]] || fail "adb_missing:${ADB}"
[[ -f "${APK}" ]] || fail "apk_missing:${APK}"
: > "${SUMMARY}"
"${ADB}" devices -l >"${DEVICES_LOG}" 2>&1 || true
mapfile -t AUTHORIZED < <(awk '$2 == "device" {print $1}' "${DEVICES_LOG}")
mapfile -t BLOCKED < <(awk '$2 == "unauthorized" || $2 == "offline" {print $1 ":" $2}' "${DEVICES_LOG}")

if ((${#AUTHORIZED[@]} == 0)); then
    printf 'ADB_BLOCKED_STATES=%s\n' "${BLOCKED[*]:-none}" | tee -a "${SUMMARY}"
    if ((${#BLOCKED[@]} > 0)); then
        printf 'DEVICE_ACCEPTANCE_BLOCKED_AUTHORIZATION=1\n' | tee -a "${SUMMARY}"
        exit 3
    fi
    printf 'DEVICE_ACCEPTANCE_BLOCKED_NO_DEVICE=1\n' | tee -a "${SUMMARY}"
    exit 2
fi

if [[ -n "${SERIAL_OVERRIDE}" ]]; then
    SERIAL="${SERIAL_OVERRIDE}"
    printf '%s\n' "${AUTHORIZED[@]}" | grep -Fxq "${SERIAL}" || fail "serial_not_authorized:${SERIAL}"
else
    PICO_SERIALS=()
    : > "${PROPS}"
    for candidate in "${AUTHORIZED[@]}"; do
        manufacturer="$("${ADB}" -s "${candidate}" shell getprop ro.product.manufacturer 2>/dev/null | tr -d '\r')"
        model="$("${ADB}" -s "${candidate}" shell getprop ro.product.model 2>/dev/null | tr -d '\r')"
        printf '%s manufacturer=%s model=%s\n' "${candidate}" "${manufacturer}" "${model}" >> "${PROPS}"
        if printf '%s %s\n' "${manufacturer}" "${model}" | grep -Eiq '(pico|bytedance)'; then
            PICO_SERIALS+=("${candidate}")
        fi
    done
    ((${#PICO_SERIALS[@]} > 0)) || fail "no_authorized_pico_device"
    ((${#PICO_SERIALS[@]} == 1)) || fail "multiple_pico_devices_set_PICO4_SERIAL"
    SERIAL="${PICO_SERIALS[0]}"
fi
printf 'SERIAL=%s\n' "${SERIAL}" | tee -a "${SUMMARY}"
{
    echo "serial=${SERIAL}"
    echo "manufacturer=$("${ADB}" -s "${SERIAL}" shell getprop ro.product.manufacturer | tr -d '\r')"
    echo "model=$("${ADB}" -s "${SERIAL}" shell getprop ro.product.model | tr -d '\r')"
    echo "device=$("${ADB}" -s "${SERIAL}" shell getprop ro.product.device | tr -d '\r')"
    echo "sdk=$("${ADB}" -s "${SERIAL}" shell getprop ro.build.version.sdk | tr -d '\r')"
    echo "release=$("${ADB}" -s "${SERIAL}" shell getprop ro.build.version.release | tr -d '\r')"
    echo "fingerprint=$("${ADB}" -s "${SERIAL}" shell getprop ro.build.fingerprint | tr -d '\r')"
} > "${PROPS}"

"${ADB}" -s "${SERIAL}" install -r -t "${APK}" >"${INSTALL_LOG}" 2>&1 || {
    cat "${INSTALL_LOG}" >&2
    fail "apk_install_failed"
}
grep -Fq 'Success' "${INSTALL_LOG}" || fail "apk_install_no_success_marker"

"${ADB}" -s "${SERIAL}" shell dumpsys package "${PACKAGE}" >"${PACKAGE_LOG}" 2>&1 || fail "package_not_visible_after_install"
grep -Fq 'versionName=0.1.0' "${PACKAGE_LOG}" || fail "installed_version_name_mismatch"
grep -Eq 'versionCode=1([[:space:]]|$)' "${PACKAGE_LOG}" || fail "installed_version_code_mismatch"

"${ADB}" -s "${SERIAL}" shell am force-stop "${PACKAGE}" >/dev/null 2>&1 || true
"${ADB}" -s "${SERIAL}" logcat -c || true
"${ADB}" -s "${SERIAL}" shell am start -W -n "${PACKAGE}/${ACTIVITY}" >"${START_LOG}" 2>&1 || {
    cat "${START_LOG}" >&2
    fail "activity_start_failed"
}
grep -Eq 'Status: ok|Complete' "${START_LOG}" || fail "activity_start_no_success_marker"
PID=""
for _ in 1 2 3 4; do
    PID="$("${ADB}" -s "${SERIAL}" shell pidof -s "${PACKAGE}" 2>/dev/null | tr -d '\r' || true)"
    [[ -n "${PID}" ]] && break
    sleep 1
done
[[ -n "${PID}" ]] || fail "process_not_running_after_launch"
printf 'PID=%s\n' "${PID}" | tee -a "${SUMMARY}"

deadline=$((SECONDS + WAIT_SECONDS))
session_seen=0
while ((SECONDS < deadline)); do
    "${ADB}" -s "${SERIAL}" logcat -d -v threadtime >"${LOGCAT}" 2>&1 || true
    if grep -Eq 'OpenXR initialization failed:|frame failed:|FATAL EXCEPTION|Fatal signal' "${LOGCAT}"; then
        fail "runtime_error_marker"
    fi
    if grep -Fq 'OpenXR session running' "${LOGCAT}"; then
        session_seen=1
        break
    fi
    sleep 1
done

"${ADB}" -s "${SERIAL}" logcat -d -v threadtime >"${LOGCAT}" 2>&1 || true
[[ "${session_seen}" == 1 ]] || fail "openxr_session_not_running_within_${WAIT_SECONDS}s"
grep -Fq 'integration initialized:' "${LOGCAT}" || fail "integration_initialized_marker_missing"
grep -Fq '4D for PICO 4 native loop started' "${LOGCAT}" || fail "native_loop_started_marker_missing"
grep -Fq 'OpenXR session running' "${LOGCAT}" || fail "openxr_session_marker_missing"

after_pid="$("${ADB}" -s "${SERIAL}" shell pidof -s "${PACKAGE}" 2>/dev/null | tr -d '\r' || true)"
[[ "${after_pid}" == "${PID}" ]] || fail "process_pid_changed_or_exited"
MARKERS="${EVIDENCE}/runtime-markers.txt"
RECEIPT="${EVIDENCE}/device-runtime-receipt.json"
grep -F '4DForPico4' "${LOGCAT}" > "${MARKERS}" || true

APK_SHA256="$(sha256sum "${APK}" | awk '{print $1}')"
MODEL="$("${ADB}" -s "${SERIAL}" shell getprop ro.product.model | tr -d '\r')"
MANUFACTURER="$("${ADB}" -s "${SERIAL}" shell getprop ro.product.manufacturer | tr -d '\r')"

{
    printf 'DEVICE_RUNTIME_STATUS=GREEN\n'
    printf 'SERIAL=%s\n' "${SERIAL}"
    printf 'MANUFACTURER=%s\n' "${MANUFACTURER}"
    printf 'MODEL=%s\n' "${MODEL}"
    printf 'PID=%s\n' "${PID}"
    printf 'PACKAGE=%s\n' "${PACKAGE}"
    printf 'APK_SHA256=%s\n' "${APK_SHA256}"
    printf 'INTEGRATION_INITIALIZED=1\n'
    printf 'NATIVE_LOOP_STARTED=1\n'
    printf 'OPENXR_SESSION_RUNNING=1\n'
    printf 'DEVICE_ACCEPTANCE_GREEN=1\n'
} | tee "${SUMMARY}"

python3 - "${RECEIPT}" "${SERIAL}" "${MANUFACTURER}" "${MODEL}" "${PID}" "${APK_SHA256}" <<'PY'
import json, sys
from datetime import datetime, timezone
from pathlib import Path
receipt_path = Path(sys.argv[1])
serial, manufacturer, model, pid, apk_sha256 = sys.argv[2:]
receipt = {
    "generated_utc": datetime.now(timezone.utc).isoformat(),
    "status": "GREEN",
    "device_runtime_status": "GREEN",
    "serial": serial,
    "manufacturer": manufacturer,
    "model": model,
    "pid": int(pid),
    "package": "org.transductive.fourd.pico4",
    "apk_sha256": apk_sha256,
    "markers": {
        "integration_initialized": True,
        "native_loop_started": True,
        "openxr_session_running": True,
    },
    "evidence": {
        "summary": "device-runtime-summary.txt",
        "properties": "device-properties.txt",
        "install": "adb-install.log",
        "start": "adb-start.log",
        "package": "package-info.txt",
        "logcat": "logcat.txt",
        "markers": "runtime-markers.txt",
    },
}
receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(f"DEVICE_RUNTIME_RECEIPT={receipt_path}")
PY

sha256sum "${RECEIPT}" | tee -a "${SUMMARY}"
