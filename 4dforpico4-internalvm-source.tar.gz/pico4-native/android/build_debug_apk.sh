#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NDK="${ANDROID_NDK_HOME:-/home/ned/.local/android/android-ndk-r29-beta2}"
BUILD_TOOLS="${ANDROID_BUILD_TOOLS:-/home/ned/.local/android/build-tools-36.0.0/android-16}"
ANDROID_JAR="${ANDROID_PLATFORM_JAR:-/mnt/c/Users/Admin/AppData/Local/Android/Sdk/platforms/android-36/android.jar}"
OUT="${PICO4_APK_OUT:-${ROOT}/build-apk}"
NDK_OUT="${ROOT}/build-android-ndk"
LIBS_OUT="${ROOT}/build-android-libs"
KEYSTORE="${PICO4_KEYSTORE:-${OUT}/debug.keystore}"

: "${PICO4_KEYSTORE_PASS:=android}"
: "${PICO4_KEY_PASS:=${PICO4_KEYSTORE_PASS}}"
export PICO4_KEYSTORE_PASS PICO4_KEY_PASS

for required in "${NDK}/ndk-build" "${BUILD_TOOLS}/aapt2" \
                "${BUILD_TOOLS}/zipalign" "${BUILD_TOOLS}/apksigner" \
                "${ANDROID_JAR}"; do
    [[ -e "${required}" ]] || { echo "missing required tool: ${required}" >&2; exit 2; }
done

mkdir -p "${OUT}" "${ROOT}/evidence/integration"
rm -rf "${OUT}/add"
mkdir -p "${OUT}/add/lib/arm64-v8a"

"${NDK}/ndk-build" \
    NDK_PROJECT_PATH="${ROOT}/android" \
    APP_BUILD_SCRIPT="${ROOT}/android/jni/Android.mk" \
    NDK_APPLICATION_MK="${ROOT}/android/jni/Application.mk" \
    NDK_OUT="${NDK_OUT}" \
    NDK_LIBS_OUT="${LIBS_OUT}" \
    -B 2>&1 | tee "${ROOT}/evidence/integration/android-ndk-build.log"

cp "${LIBS_OUT}/arm64-v8a/libfourdpico4.so" "${OUT}/add/lib/arm64-v8a/"
cp "${LIBS_OUT}/arm64-v8a/libopenxr_loader.so" "${OUT}/add/lib/arm64-v8a/"
# Normalize ZIP entry mtimes so equivalent source/toolchain inputs produce byte-identical APKs.
touch -t 198001010000.00 \
    "${OUT}/add/lib/arm64-v8a/libfourdpico4.so" \
    "${OUT}/add/lib/arm64-v8a/libopenxr_loader.so"

rm -f "${OUT}/fourd-base-unsigned.apk" \
      "${OUT}/fourd-with-libs-unsigned.apk" \
      "${OUT}/fourd-aligned-unsigned.apk" \
      "${OUT}/4d-for-pico4-debug.apk" \
      "${OUT}/4d-for-pico4-debug.apk.idsig"

"${BUILD_TOOLS}/aapt2" link \
    -o "${OUT}/fourd-base-unsigned.apk" \
    --manifest "${ROOT}/android/AndroidManifest.xml" \
    -I "${ANDROID_JAR}"

cp "${OUT}/fourd-base-unsigned.apk" "${OUT}/fourd-with-libs-unsigned.apk"
(
    cd "${OUT}/add"
    zip -X -0 -q "../fourd-with-libs-unsigned.apk" \
        lib/arm64-v8a/libfourdpico4.so lib/arm64-v8a/libopenxr_loader.so
)

"${BUILD_TOOLS}/zipalign" -P 16 -f 4 \
    "${OUT}/fourd-with-libs-unsigned.apk" \
    "${OUT}/fourd-aligned-unsigned.apk"

if [[ ! -f "${KEYSTORE}" ]]; then
    keytool -genkeypair \
        -keystore "${KEYSTORE}" \
        -storepass:env PICO4_KEYSTORE_PASS \
        -keypass:env PICO4_KEY_PASS \
        -alias androiddebugkey \
        -dname "CN=AndroidDebug,O=Android,C=US" \
        -keyalg RSA -keysize 2048 -validity 10000 -noprompt
fi

"${BUILD_TOOLS}/apksigner" sign \
    --v1-signing-enabled false \
    --v2-signing-enabled false \
    --v3-signing-enabled true \
    --v4-signing-enabled false \
    --ks "${KEYSTORE}" \
    --ks-key-alias androiddebugkey \
    --ks-pass env:PICO4_KEYSTORE_PASS \
    --key-pass env:PICO4_KEY_PASS \
    --out "${OUT}/4d-for-pico4-debug.apk" \
    "${OUT}/fourd-aligned-unsigned.apk"

"${BUILD_TOOLS}/zipalign" -c -P 16 -v 4 "${OUT}/4d-for-pico4-debug.apk"
"${BUILD_TOOLS}/apksigner" verify --verbose --print-certs "${OUT}/4d-for-pico4-debug.apk"
"${BUILD_TOOLS}/aapt2" dump badging "${OUT}/4d-for-pico4-debug.apk"
sha256sum "${OUT}/4d-for-pico4-debug.apk"

echo "APK_BUILD_GREEN=${OUT}/4d-for-pico4-debug.apk"
