#include "core/math4.h"
#include "core/tesseract.h"
#include "core/trackball4.h"
#include "core/trackball_mapping.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <iostream>
#include <string>

namespace {
using namespace fourd;

using FloatVec4 = std::array<float, 4>;
using FloatMat4 = std::array<float, 16>;

int failures = 0;
int cases = 0;

double max_reference_matrix_difference = 0.0;
std::size_t max_reference_iterations = 0;

bool approx(double a, double b, double tolerance = 2e-6) {
    return std::abs(a - b) <= tolerance;
}
void check(bool condition, const std::string& name) {
    ++cases;
    if (condition) {
        std::cout << "PASS reference " << cases << " - " << name << '\n';
    } else {
        ++failures;
        std::cerr << "FAIL reference " << cases << " - " << name << '\n';
    }
}

FloatMat4 identityFloat() {
    FloatMat4 matrix{};
    for (std::size_t i = 0; i < 4; ++i) matrix[i * 4 + i] = 1.0f;
    return matrix;
}

float floatDot(const FloatVec4& a, const FloatVec4& b) {
    float result = 0.0f;
    for (std::size_t k = 0; k < 4; ++k) result += a[k] * b[k];
    return result;
}

FloatMat4 multiplyFloat(const FloatMat4& a, const FloatMat4& b) {
    FloatMat4 out{};
    for (std::size_t row = 0; row < 4; ++row) {
        for (std::size_t col = 0; col < 4; ++col) {
            float sum = 0.0f;
            for (std::size_t k = 0; k < 4; ++k) sum += a[row * 4 + k] * b[k * 4 + col];
            out[row * 4 + col] = sum;
        }
    }
    return out;
}

struct UnityRotationResult {
    FloatMat4 matrix{identityFloat()};
    std::size_t iterations{0};
    bool converged{false};
};

UnityRotationResult unityComputeRotation(const FloatVec4& a, const FloatVec4& b) {
    UnityRotationResult result;
    FloatMat4& rotation = result.matrix;
    for (std::size_t row = 0; row < 4; ++row) {
        for (std::size_t col = 0; col < 4; ++col) {
            rotation[row * 4 + col] += 2.0f * (b[row] - a[row]) * a[col];
        }
    }

    float totalError = 1.0f;
    while (totalError >= 0.00001f && result.iterations < 4096) {
        ++result.iterations;
        FloatMat4 error{};
        for (std::size_t i = 0; i < 3; ++i) {
            for (std::size_t j = i + 1; j < 4; ++j) {
                FloatVec4 row1{};
                FloatVec4 row2{};
                for (std::size_t k = 0; k < 4; ++k) {
                    row1[k] = rotation[i * 4 + k];
                    row2[k] = rotation[j * 4 + k];
                }
                const float pairDot = floatDot(row1, row2);
                for (std::size_t k = 0; k < 4; ++k) {
                    error[i * 4 + k] += rotation[j * 4 + k] * pairDot / 2.0f;
                    error[j * 4 + k] += rotation[i * 4 + k] * pairDot / 2.0f;
                }
            }
        }

        totalError = 0.0f;
        for (std::size_t i = 0; i < 4; ++i) {
            FloatVec4 row{};
            for (std::size_t k = 0; k < 4; ++k) {
                rotation[i * 4 + k] -= error[i * 4 + k];
                totalError += error[i * 4 + k] * error[i * 4 + k];
                row[k] = rotation[i * 4 + k];
            }
            const float rowNorm = static_cast<float>(std::sqrt(floatDot(row, row)));
            for (std::size_t k = 0; k < 4; ++k) rotation[i * 4 + k] /= rowNorm;
        }
    }
    result.converged = totalError < 0.00001f;
    max_reference_iterations = std::max(max_reference_iterations, result.iterations);
    return result;
}

FloatVec4 toFloat(const Vec4& value) {
    return {static_cast<float>(value.x), static_cast<float>(value.y),
            static_cast<float>(value.z), static_cast<float>(value.w)};
}

double matrixDifference(const Mat4& actual, const FloatMat4& expected) {
    double result = 0.0;
    for (std::size_t row = 0; row < 4; ++row) {
        for (std::size_t col = 0; col < 4; ++col) {
            result = std::max(result,
                std::abs(actual(row, col) - static_cast<double>(expected[row * 4 + col])));
        }
    }
    max_reference_matrix_difference = std::max(max_reference_matrix_difference, result);
    return result;
}

struct UnityTrackballReference {
    FloatMat4 accumulated{identityFloat()};

    UnityRotationResult rotate(const Vec4& a, const Vec4& b) {
        UnityRotationResult incremental = unityComputeRotation(toFloat(a), toFloat(b));
        if (incremental.converged) accumulated = multiplyFloat(incremental.matrix, accumulated);
        return incremental;
    }
};

bool compareIncremental(const Vec4& a, const Vec4& b, double tolerance,
                        const std::string& name) {
    UnityTrackballReference reference;
    const UnityRotationResult expected = reference.rotate(a, b);
    Trackball4 actual;
    const bool accepted = actual.rotate(a, b);
    const double difference = matrixDifference(actual.lastIncremental(), expected.matrix);
    std::cout << "METRIC " << name << "_matrix_diff=" << difference
              << " iterations=" << expected.iterations << '\n';
    return expected.converged && accepted && difference <= tolerance;
}

}  // namespace

int main() {
    using namespace fourd;
    constexpr double kReferenceTolerance = 3e-6;

    const Tesseract t;
    check(t.sourceVertices()[0].x == -0.175 && t.sourceVertices()[0].y == -0.175 &&
          t.sourceVertices()[0].z == -0.175 && t.sourceVertices()[0].w == -0.175 &&
          t.sourceVertices()[15].x == 0.175 && t.sourceVertices()[15].y == 0.175 &&
          t.sourceVertices()[15].z == 0.175 && t.sourceVertices()[15].w == 0.175,
          "Unity HyperCube loop order produces expected endpoint vertices");

    check(t.edges()[0] == Edge{0, 1} && t.edges()[7] == Edge{14, 15} &&
          t.edges()[8] == Edge{0, 2} && t.edges()[16] == Edge{0, 4} &&
          t.edges()[24] == Edge{0, 8} && t.edges()[31] == Edge{7, 15},
          "Unity HyperCube hard-coded edge ordering is preserved");

    const auto center = mapTrackball({0.0, 0.0, 0.0}, {});
    check(center.valid && center.point.x == 0.0 && center.point.y == 0.0 &&
          center.point.z == 0.0 && center.point.w == 1.0,
          "Unity center maps to positive-W pole (0,0,0,1)");

    const auto halfX = mapTrackball({3.0 / 16.0, 0.0, 0.0}, {});
    check(halfX.valid && approx(halfX.point.x, 0.5, 1e-15) &&
          approx(halfX.point.w, std::sqrt(3.0) / 2.0, 1e-15),
          "Unity 8/3 mapping reproduces the half-X reference case");

    const auto clampX = mapTrackball({3.0 / 4.0, 0.0, 0.0}, {});
    check(clampX.valid && clampX.clamped && approx(clampX.point.x, 1.0, 1e-15) &&
          clampX.point.y == 0.0 && clampX.point.z == 0.0 && clampX.point.w == 0.0,
          "Unity outside-sphere mapping clamps to +X equator");
    const double angleXW = 0.1;
    const Vec4 aXW{0.0, 0.0, 0.0, 1.0};
    const Vec4 bXW{std::sin(angleXW), 0.0, 0.0, std::cos(angleXW)};
    check(compareIncremental(aXW, bXW, kReferenceTolerance, "ref_xw"),
          "production Trackball matches source-faithful Unity float X-W drag");

    const double angleXY = 0.08;
    const Vec4 aXY{1.0, 0.0, 0.0, 0.0};
    const Vec4 bXY{std::cos(angleXY), std::sin(angleXY), 0.0, 0.0};
    check(compareIncremental(aXY, bXY, kReferenceTolerance, "ref_xy"),
          "production Trackball matches source-faithful Unity float X-Y drag");

    const Vec4 aGeneral = normalize(Vec4{0.21, -0.34, 0.17, 0.89});
    const Vec4 bGeneral = normalize(Vec4{0.225, -0.328, 0.164, 0.891});
    check(compareIncremental(aGeneral, bGeneral, kReferenceTolerance, "ref_general"),
          "production Trackball matches source-faithful Unity float general 4D drag");

    UnityTrackballReference referenceAccumulated;
    Trackball4 actualAccumulated;
    const Vec4 pole{0.0, 0.0, 0.0, 1.0};
    const Vec4 bx{std::sin(0.07), 0.0, 0.0, std::cos(0.07)};
    const Vec4 by{0.0, std::sin(-0.05), 0.0, std::cos(-0.05)};
    const UnityRotationResult firstRef = referenceAccumulated.rotate(pole, bx);
    const UnityRotationResult secondRef = referenceAccumulated.rotate(pole, by);
    const bool firstActual = actualAccumulated.rotate(pole, bx);
    const bool secondActual = actualAccumulated.rotate(pole, by);
    const double accumulatedDifference = matrixDifference(actualAccumulated.matrix(),
                                                          referenceAccumulated.accumulated);
    std::cout << "METRIC ref_accum_matrix_diff=" << accumulatedDifference << '\n';
    check(firstRef.converged && secondRef.converged && firstActual && secondActual &&
              accumulatedDifference <= 6e-6,
          "production accumulation order matches source-faithful Unity rot * accumulated");

    check(max_reference_iterations <= Trackball4::kMaxIterations,
          "production convergence guard exceeds all source-reference iteration counts");

    std::cout << "METRIC max_reference_matrix_difference="
              << max_reference_matrix_difference << '\n';
    std::cout << "METRIC max_reference_iterations=" << max_reference_iterations << '\n';
    std::cout << "REFERENCE CASES " << (failures == 0 ? "PASSED" : "FAILED")
              << ": " << cases << ", failures=" << failures << '\n';
    return failures == 0 ? 0 : 1;
}
