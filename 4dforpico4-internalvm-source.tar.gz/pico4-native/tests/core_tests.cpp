#include "core/interaction.h"
#include "core/math4.h"
#include "core/projection4.h"
#include "core/render_packet.h"
#include "core/tesseract.h"
#include "core/trackball4.h"
#include "core/trackball_mapping.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <utility>

namespace {
using namespace fourd;
int failures = 0;
int tests_run = 0;
double max_norm_error = 0.0;
double max_incremental_norm_error = 0.0;
double max_orthonormality_error = 0.0;

// The source Trackball stops its row-orthonormalization iteration when the
// squared correction sum falls below 1e-5. These limits are intentionally
// much tighter than that source stopping criterion without changing its math.
constexpr double kIncrementalNormTolerance = 5e-6;
constexpr double kAccumulatedOrthonormalityTolerance = 1e-5;
constexpr double kLongRunNormTolerance = 5e-5;

bool approx(double a, double b, double tolerance = 1e-10) {
    return std::abs(a - b) <= tolerance;
}
void check(bool condition, const std::string& name) {
    ++tests_run;
    if (condition) {
        std::cout << "PASS " << tests_run << " - " << name << '\n';
    } else {
        ++failures;
        std::cerr << "FAIL " << tests_run << " - " << name << '\n';
    }
}

bool vec4Approx(const Vec4& a, const Vec4& b, double tolerance = 1e-10) {
    return approx(a.x, b.x, tolerance) && approx(a.y, b.y, tolerance) &&
           approx(a.z, b.z, tolerance) && approx(a.w, b.w, tolerance);
}

std::string snapshot(const Interaction& interaction, const Tesseract& tesseract,
                     const Projection4& projection) {
    const RenderPacket packet = makeRenderPacket(tesseract, interaction, projection);
    std::ostringstream out;
    out << std::hexfloat;
    for (double value : interaction.trackball().matrix().values) out << value << ';';
    out << interaction.translation().x << ';' << interaction.translation().y << ';'
        << interaction.translation().z << ';' << interaction.scale() << ';'
        << static_cast<int>(interaction.projectionMode()) << ';';
    for (const Vec3& p : packet.projected_vertices) out << p.x << ',' << p.y << ',' << p.z << ';';
    for (double w : packet.transformed_w) out << w << ';';
    return out.str();
}

void scriptedSequence(Interaction& interaction) {
    FrameInput frame;
    frame.trigger = {true, true, false};
    frame.rightControllerPosition = {0.02, -0.01, 0.03};
    interaction.update(frame);
    for (int i = 1; i <= 20; ++i) {
        frame.trigger = {false, true, false};
        frame.rightControllerPosition = {0.02 + 0.001 * i, -0.01 + 0.0003 * i, 0.03 - 0.0004 * i};
        interaction.update(frame);
    }
    frame.trigger = {false, false, true};
    interaction.update(frame);

    frame = {};
    frame.rightSqueeze = {true, true, false};
    frame.rightControllerPosition = {0.25, 0.1, -0.2};
    interaction.update(frame);
    frame.rightSqueeze = {false, true, false};
    frame.rightControllerPosition = {0.4, 0.0, -0.1};
    interaction.update(frame);
    frame.rightSqueeze = {false, false, true};
    interaction.update(frame);

    frame = {};
    frame.leftSqueeze = {true, true, false};
    frame.rightSqueeze = {true, true, false};
    frame.leftControllerPosition = {-0.2, 0.0, 0.0};
    frame.rightControllerPosition = {0.2, 0.0, 0.0};
    interaction.update(frame);
    frame.leftSqueeze = {false, true, false};
    frame.rightSqueeze = {false, true, false};
    frame.leftControllerPosition = {-0.3, 0.0, 0.0};
    frame.rightControllerPosition = {0.3, 0.0, 0.0};
    interaction.update(frame);
    frame = {};
    frame.projectionToggleCommand = true;
    interaction.update(frame);
}

}  // namespace

int main() {
    using namespace fourd;
    const Tesseract tesseract;
    {
        std::set<std::array<int, 4>> unique;
        for (const Vec4& v : tesseract.sourceVertices()) {
            unique.insert({v.x > 0.0, v.y > 0.0, v.z > 0.0, v.w > 0.0});
        }
        check(unique.size() == 16U, "exactly 16 unique tesseract vertices");
    }
    {
        std::set<std::pair<int, int>> unique;
        for (const Edge& e : tesseract.edges()) {
            const int a = std::min<int>(e[0], e[1]);
            const int b = std::max<int>(e[0], e[1]);
            unique.emplace(a, b);
        }
        check(unique.size() == 32U, "exactly 32 unique edges");
    }
    {
        std::array<int, 16> degree{};
        for (const Edge& e : tesseract.edges()) { ++degree[e[0]]; ++degree[e[1]]; }
        check(std::all_of(degree.begin(), degree.end(), [](int d) { return d == 4; }),
              "every vertex has degree exactly 4");
    }
    {
        bool ok = true;
        for (const Edge& e : tesseract.edges()) {
            int differences = 0;
            for (std::size_t axis = 0; axis < 4; ++axis) {
                if (!approx(tesseract.sourceVertices()[e[0]][axis],
                            tesseract.sourceVertices()[e[1]][axis])) ++differences;
            }
            ok = ok && differences == 1;
        }
        check(ok, "every edge differs in exactly one 4D coordinate");
    }
    {
        Trackball4 tb;
        bool ok = true;
        for (const Vec4& v : tesseract.sourceVertices()) ok = ok && vec4Approx(tb.transform(v), v, 1e-15);
        check(ok, "identity Trackball leaves every vertex unchanged");
    }
    Trackball4 accumulated;
    {
        std::mt19937 rng(0x4D4D4D4Du);
        std::uniform_real_distribution<double> step(-0.0015, 0.0015);
        Vec3 controller{0.02, -0.015, 0.01};
        Vec4 previous = mapTrackball(controller, {}).point;
        bool ok = true;
        const std::array<Vec4, 8> probes{{
            {1,0,0,0}, {0,1,0,0}, {0,0,1,0}, {0,0,0,1},
            normalize(Vec4{1,1,0,0}), normalize(Vec4{1,-2,3,-4}),
            normalize(Vec4{-3,1,2,0.5}), normalize(Vec4{0.2,-0.7,0.1,0.67})
        }};
        for (int i = 0; i < 5000; ++i) {
            controller.x = std::clamp(controller.x + step(rng), -0.12, 0.12);
            controller.y = std::clamp(controller.y + step(rng), -0.12, 0.12);
            controller.z = std::clamp(controller.z + step(rng), -0.12, 0.12);
            const Vec4 current = mapTrackball(controller, {}).point;
            ok = ok && accumulated.rotate(previous, current);
            for (const Vec4& probe : probes) {
                const double error = std::abs(length(accumulated.lastIncremental() * probe) - 1.0);
                max_incremental_norm_error = std::max(max_incremental_norm_error, error);
                max_norm_error = std::max(max_norm_error, error);
                ok = ok && error < kIncrementalNormTolerance;
            }
            previous = current;
        }
        check(ok, "every incremental Trackball rotation preserves 4D vector norm");
    }
    max_orthonormality_error = orthonormalityError(accumulated.matrix());
    check(max_orthonormality_error < kAccumulatedOrthonormalityTolerance,
          "accumulated rotation remains orthonormal after deterministic random drags");
    check(std::abs(determinant(accumulated.matrix()) - 1.0) < 1e-8,
          "determinant stays close to +1 for proper rotations");
    {
        Trackball4 tb;
        const Vec4 a = normalize(Vec4{0.1, -0.2, 0.05, 0.97});
        const Mat4 before = tb.matrix();
        const bool accepted = tb.rotate(a, a);
        check(accepted && maxAbsDifference(tb.lastIncremental(), Mat4::identity()) < 1e-12 &&
              maxAbsDifference(tb.matrix(), before) < 1e-12,
              "A == B produces identity/no meaningful rotation");
    }
    {
        const auto mapped = mapTrackball({0.1, -0.05, 0.02}, {});
        check(mapped.valid && !mapped.clamped && mapped.point.w > 0.0 &&
              approx(length(mapped.point), 1.0, 1e-12),
              "inside-sphere mapping is unit Vec4 with positive W");
    }
    {
        const auto boundary = mapTrackball({3.0 / 8.0, 0.0, 0.0}, {});
        const auto outside = mapTrackball({0.75, 0.0, 0.0}, {});
        check(boundary.valid && outside.valid && boundary.point.w == 0.0 && outside.point.w == 0.0 &&
              approx(length(Vec3{boundary.point.x, boundary.point.y, boundary.point.z}), 1.0, 1e-12) &&
              approx(length(Vec3{outside.point.x, outside.point.y, outside.point.z}), 1.0, 1e-12),
              "boundary/outside mapping clamps to W=0 and unit XYZ");
    }
    {
        const auto mapped = mapTrackball({0.1, 0.0, 0.0}, {});
        check(approx(mapped.point.x, 0.1 * 8.0 / 3.0, 1e-15),
              "original 8/3 gain reproduced mechanically");
    }
    {
        InteractionConfig config;
        config.defaultTranslation = {1.0, 2.0, 3.0};
        Interaction interaction(config);
        FrameInput frame;
        frame.rightSqueeze = {true, true, false};
        frame.rightControllerPosition = {0.25, -0.5, 0.75};
        interaction.update(frame);
        frame.rightSqueeze = {false, true, false};
        frame.rightControllerPosition = {1.25, -1.0, 1.0};
        interaction.update(frame);
        check(approx(interaction.translation().x, 2.0) && approx(interaction.translation().y, 1.5) &&
              approx(interaction.translation().z, 3.25),
              "translation follows captured grip offset correctly");
    }
    {
        Interaction interaction;
        FrameInput frame;
        frame.leftSqueeze = {true, true, false};
        frame.rightSqueeze = {true, true, false};
        frame.leftControllerPosition = {-1.0, 0.0, 0.0};
        frame.rightControllerPosition = {1.0, 0.0, 0.0};
        interaction.update(frame);
        frame.leftSqueeze = {false, true, false};
        frame.rightSqueeze = {false, true, false};
        frame.leftControllerPosition = {-2.0, 0.0, 0.0};
        frame.rightControllerPosition = {2.0, 0.0, 0.0};
        interaction.update(frame);
        check(approx(interaction.scale(), 2.0), "bilateral scale ratio is correct");
    }
    {
        InteractionConfig config;
        config.minimumScale = 0.5;
        config.maximumScale = 3.0;
        Interaction interaction(config);
        FrameInput frame;
        frame.leftSqueeze = {true, true, false};
        frame.rightSqueeze = {true, true, false};
        frame.leftControllerPosition = {-1.0, 0.0, 0.0};
        frame.rightControllerPosition = {1.0, 0.0, 0.0};
        interaction.update(frame);
        frame.leftSqueeze = {false, true, false};
        frame.rightSqueeze = {false, true, false};
        frame.leftControllerPosition = {-10.0, 0.0, 0.0};
        frame.rightControllerPosition = {10.0, 0.0, 0.0};
        interaction.update(frame);
        const bool high = approx(interaction.scale(), 3.0);
        interaction.reset();
        frame.leftSqueeze = {true, true, false};
        frame.rightSqueeze = {true, true, false};
        frame.leftControllerPosition = {-1.0, 0.0, 0.0};
        frame.rightControllerPosition = {1.0, 0.0, 0.0};
        interaction.update(frame);
        frame.leftSqueeze = {false, true, false};
        frame.rightSqueeze = {false, true, false};
        frame.leftControllerPosition = {-0.05, 0.0, 0.0};
        frame.rightControllerPosition = {0.05, 0.0, 0.0};
        interaction.update(frame);
        check(high && approx(interaction.scale(), 0.5), "scale limits clamp correctly");
    }
    {
        Interaction interaction;
        FrameInput frame;
        frame.rightSqueeze = {true, true, false};
        frame.rightControllerPosition = {0.0, 0.0, 0.0};
        interaction.update(frame);
        frame.rightSqueeze = {false, true, false};
        frame.rightControllerPosition = {1.0, 0.0, 0.0};
        interaction.update(frame);
        const Vec3 released_at = interaction.translation();
        frame.rightSqueeze = {false, false, true};
        interaction.update(frame);
        frame = {};
        frame.rightControllerPosition = {100.0, 100.0, 100.0};
        interaction.update(frame);
        check(approx(interaction.translation().x, released_at.x) &&
              approx(interaction.translation().y, released_at.y) &&
              approx(interaction.translation().z, released_at.z),
              "releasing controls terminates manipulation cleanly");
    }
    {
        InteractionConfig config;
        config.defaultTranslation = {0.25, -0.5, 0.75};
        config.defaultScale = 1.5;
        config.defaultProjection = ProjectionMode::Orthographic;
        Interaction interaction(config);
        scriptedSequence(interaction);
        FrameInput reset;
        reset.resetCommand = true;
        interaction.update(reset);
        check(maxAbsDifference(interaction.trackball().matrix(), Mat4::identity()) < 1e-15 &&
              approx(interaction.translation().x, 0.25) && approx(interaction.translation().y, -0.5) &&
              approx(interaction.translation().z, 0.75) && approx(interaction.scale(), 1.5) &&
              interaction.projectionMode() == ProjectionMode::Orthographic,
              "reset restores identity/default translation/default scale/default projection");
    }
    {
        Projection4 projection;
        const Vec4 p{1.25, -2.5, 3.75, 999.0};
        const Vec3 q = projection.project(p, ProjectionMode::Orthographic);
        check(q.x == p.x && q.y == p.y && q.z == p.z,
              "orthographic projection exactly drops W");
    }
    {
        Projection4 projection(1.0, 1e-6);
        const Vec3 a = projection.project({1.0, -2.0, 3.0, 1.0}, ProjectionMode::WPerspective);
        const Vec3 b = projection.project({1.0, -2.0, 3.0, 1.0 - 1e-15}, ProjectionMode::WPerspective);
        check(isFinite(a) && isFinite(b), "perspective projection remains finite near denominator boundary");
    }

    Interaction long_run;
    Projection4 projection;
    bool long_run_valid = true;
    for (int i = 0; i < 6000; ++i) {
        FrameInput frame;
        const int phase = i % 240;
        const double t = static_cast<double>(i) * 0.013;
        frame.trackballCenter = long_run.translation();
        frame.rightControllerPosition = long_run.translation() +
            Vec3{0.03 * std::sin(t), 0.025 * std::cos(0.7 * t), 0.02 * std::sin(0.31 * t)};
        frame.leftControllerPosition = long_run.translation() +
            Vec3{-0.12 - 0.01 * std::sin(0.2 * t), 0.0, 0.0};

        if (phase < 120) frame.trigger = {phase == 0, true, false};
        else if (phase == 120) frame.trigger = {false, false, true};
        else if (phase < 170) frame.rightSqueeze = {phase == 121, true, false};
        else if (phase == 170) frame.rightSqueeze = {false, false, true};
        else if (phase < 230) {
            frame.leftSqueeze = {phase == 171, true, false};
            frame.rightSqueeze = {phase == 171, true, false};
            const double spread = 0.12 + 0.02 * std::sin(0.15 * t);
            frame.leftControllerPosition = long_run.translation() + Vec3{-spread, 0.0, 0.0};
            frame.rightControllerPosition = long_run.translation() + Vec3{spread, 0.0, 0.0};
        } else if (phase == 230) {
            frame.leftSqueeze = {false, false, true};
            frame.rightSqueeze = {false, false, true};
        }
        if (i > 0 && i % 997 == 0) frame.projectionToggleCommand = true;
        long_run.update(frame);
        const RenderPacket packet = makeRenderPacket(tesseract, long_run, projection);
        long_run_valid = long_run_valid && packet.valid && isFinite(long_run.trackball().matrix()) &&
                         isFinite(long_run.translation()) && std::isfinite(long_run.scale());
    }
    {
        FrameInput bad;
        bad.trigger = {true, true, false};
        bad.rightControllerPosition = {std::numeric_limits<double>::quiet_NaN(), 0.0, 0.0};
        bad.trackballCenter = long_run.translation();
        long_run.update(bad);
        const RenderPacket packet = makeRenderPacket(tesseract, long_run, projection);
        long_run_valid = long_run_valid && packet.valid;
    }
    check(long_run_valid, "thousands of deterministic interaction steps produce no NaN/Inf");

    {
        bool ok = true;
        for (const Vec4& source : tesseract.sourceVertices()) {
            const Vec4 transformed = long_run.trackball().transform(source);
            const double error = std::abs(length(transformed) - length(source));
            max_norm_error = std::max(max_norm_error, error);
            ok = ok && error < kLongRunNormTolerance;
        }
        check(ok, "4D norm invariants survive long accumulated interaction sequences");
    }
    {
        Interaction a;
        Interaction b;
        scriptedSequence(a);
        scriptedSequence(b);
        check(snapshot(a, tesseract, projection) == snapshot(b, tesseract, projection),
              "deterministic scripted runs are byte-for-byte repeatable");
    }

    std::cout << std::setprecision(17)
              << "METRIC max_norm_error=" << max_norm_error << '\n'
              << "METRIC max_incremental_norm_error=" << max_incremental_norm_error << '\n'
              << "METRIC max_orthonormality_error=" << max_orthonormality_error << '\n'
              << "METRIC accumulated_determinant=" << determinant(accumulated.matrix()) << '\n'
              << "ALL TESTS " << (failures == 0 ? "PASSED" : "FAILED") << ": "
              << tests_run << " acceptance tests, failures=" << failures << '\n';
    return failures == 0 ? 0 : 1;
}
