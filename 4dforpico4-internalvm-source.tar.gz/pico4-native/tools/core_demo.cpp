#include "core/interaction.h"
#include "core/projection4.h"
#include "core/render_packet.h"
#include "core/tesseract.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>

namespace {
using namespace fourd;

void printVec4(const char* label, std::size_t index, const Vec4& v) {
    std::cout << label << '[' << index << "]=" << v.x << ',' << v.y << ',' << v.z << ',' << v.w << '\n';
}

bool finitePacket(const RenderPacket& packet) {
    if (!packet.valid || !isFinite(packet.object_translation) || !std::isfinite(packet.uniform_scale)) return false;
    for (std::size_t i = 0; i < packet.projected_vertices.size(); ++i) {
        if (!isFinite(packet.projected_vertices[i]) || !std::isfinite(packet.transformed_w[i])) return false;
    }
    return true;
}
}  // namespace

int main() {
    using namespace fourd;
    std::cout << std::setprecision(17);
    Tesseract tesseract;
    Interaction interaction;
    Projection4 projection(1.25, 1e-6);

    std::cout << "TOPOLOGY vertices=" << Tesseract::kVertexCount
              << " edges=" << Tesseract::kEdgeCount
              << " valid=" << (tesseract.validateTopology() ? "true" : "false") << '\n';
    for (std::size_t i = 0; i < Tesseract::kVertexCount; ++i)
        printVec4("BEFORE", i, tesseract.sourceVertices()[i]);
    FrameInput frame;
    frame.trigger = {true, true, false};
    frame.rightControllerPosition = {0.02, -0.01, 0.015};
    frame.trackballCenter = interaction.translation();
    interaction.update(frame);
    for (int i = 1; i <= 80; ++i) {
        const double t = static_cast<double>(i) * 0.04;
        frame.trigger = {false, true, false};
        frame.trackballCenter = interaction.translation();
        frame.rightControllerPosition = {0.02 + 0.02 * std::sin(t),
                                         -0.01 + 0.015 * std::sin(0.7 * t),
                                         0.015 + 0.012 * std::cos(0.5 * t)};
        interaction.update(frame);
    }
    frame.trigger = {false, false, true};
    interaction.update(frame);

    frame = {};
    frame.rightSqueeze = {true, true, false};
    frame.rightControllerPosition = {0.15, 0.05, -0.1};
    interaction.update(frame);
    frame.rightSqueeze = {false, true, false};
    frame.rightControllerPosition = {0.28, -0.03, -0.02};
    interaction.update(frame);
    frame.rightSqueeze = {false, false, true};
    interaction.update(frame);

    frame = {};
    frame.leftSqueeze = {true, true, false};
    frame.rightSqueeze = {true, true, false};
    frame.leftControllerPosition = {-0.2, 0.0, 0.0};
    frame.rightControllerPosition = {0.2, 0.0, 0.0};
    interaction.update(frame);
    frame.leftSqueeze = {false, true, false};
    frame.rightSqueeze = {false, true, false};
    frame.leftControllerPosition = {-0.27, 0.0, 0.0};
    frame.rightControllerPosition = {0.27, 0.0, 0.0};
    interaction.update(frame);
    frame = {};
    frame.projectionToggleCommand = true;
    interaction.update(frame);
    double min_w = std::numeric_limits<double>::infinity();
    double max_w = -std::numeric_limits<double>::infinity();
    double max_norm_error = 0.0;
    for (std::size_t i = 0; i < Tesseract::kVertexCount; ++i) {
        const Vec4 transformed = interaction.trackball().transform(tesseract.sourceVertices()[i]);
        printVec4("AFTER", i, transformed);
        min_w = std::min(min_w, transformed.w);
        max_w = std::max(max_w, transformed.w);
        max_norm_error = std::max(max_norm_error,
            std::abs(length(transformed) - length(tesseract.sourceVertices()[i])));
    }

    const RenderPacket packet = makeRenderPacket(tesseract, interaction, projection);
    Vec3 min_bound{std::numeric_limits<double>::infinity(), std::numeric_limits<double>::infinity(),
                   std::numeric_limits<double>::infinity()};
    Vec3 max_bound{-std::numeric_limits<double>::infinity(), -std::numeric_limits<double>::infinity(),
                   -std::numeric_limits<double>::infinity()};
    for (const Vec3& p : packet.projected_vertices) {
        min_bound.x = std::min(min_bound.x, p.x); min_bound.y = std::min(min_bound.y, p.y); min_bound.z = std::min(min_bound.z, p.z);
        max_bound.x = std::max(max_bound.x, p.x); max_bound.y = std::max(max_bound.y, p.y); max_bound.z = std::max(max_bound.z, p.z);
    }

    const double residual = orthonormalityError(interaction.trackball().matrix());
    const double det = determinant(interaction.trackball().matrix());
    std::cout << "METRIC orthonormality_residual=" << residual << '\n';
    std::cout << "METRIC determinant=" << det << '\n';
    std::cout << "METRIC max_norm_error=" << max_norm_error << '\n';
    std::cout << "METRIC transformed_w_min=" << min_w << " transformed_w_max=" << max_w << '\n';
    std::cout << "METRIC translation=" << packet.object_translation.x << ',' << packet.object_translation.y << ',' << packet.object_translation.z << '\n';
    std::cout << "METRIC scale=" << packet.uniform_scale << '\n';
    std::cout << "METRIC projection_mode=" << static_cast<int>(packet.projection_mode) << '\n';
    std::cout << "METRIC projected_bounds_min=" << min_bound.x << ',' << min_bound.y << ',' << min_bound.z << '\n';
    std::cout << "METRIC projected_bounds_max=" << max_bound.x << ',' << max_bound.y << ',' << max_bound.z << '\n';

    const bool ok = tesseract.validateTopology() && finitePacket(packet) && residual < 1e-8 &&
                    std::abs(det - 1.0) < 1e-8 && max_norm_error < 1e-8;
    std::cout << "DEMO_RESULT=" << (ok ? "GREEN" : "RED") << '\n';
    return ok ? 0 : 1;
}
