#include "core/trackball4.h"

#include <cmath>

namespace fourd {
namespace {

bool orthonormalizeRows(Mat4& rotation, double convergenceError, std::size_t maxIterations,
                        std::size_t& iterations, double& finalTotalError) {
    iterations = 0;
    finalTotalError = 0.0;
    for (std::size_t iteration = 1; iteration <= maxIterations; ++iteration) {
        Mat4 error;
        for (std::size_t i = 0; i < 3; ++i) {
            for (std::size_t j = i + 1; j < 4; ++j) {
                double pairDot = 0.0;
                for (std::size_t k = 0; k < 4; ++k) pairDot += rotation(i,k) * rotation(j,k);
                for (std::size_t k = 0; k < 4; ++k) {
                    error(i,k) += rotation(j,k) * pairDot / 2.0;
                    error(j,k) += rotation(i,k) * pairDot / 2.0;
                }
            }
        }

        double totalError = 0.0;
        for (std::size_t i = 0; i < 4; ++i) {
            for (std::size_t k = 0; k < 4; ++k) {
                rotation(i,k) -= error(i,k);
                totalError += error(i,k) * error(i,k);
            }
            double rowNormSquared = 0.0;
            for (std::size_t k = 0; k < 4; ++k) rowNormSquared += rotation(i,k) * rotation(i,k);
            const double rowNorm = std::sqrt(rowNormSquared);
            if (!std::isfinite(rowNorm) || rowNorm <= 1e-12) {
                iterations = iteration;
                finalTotalError = totalError;
                return false;
            }
            for (std::size_t k = 0; k < 4; ++k) rotation(i,k) /= rowNorm;
        }

        iterations = iteration;
        finalTotalError = totalError;
        if (!isFinite(rotation) || !std::isfinite(totalError)) return false;
        if (totalError < convergenceError) return true;
    }
    return false;
}

}  // namespace

Trackball4::Trackball4() { reset(); }

void Trackball4::reset() {
    matrix_ = Mat4::identity();
    last_incremental_ = Mat4::identity();
    diagnostics_ = {};
}

bool Trackball4::rotate(const Vec4& a, const Vec4& b) {
    Mat4 incremental;
    if (!computeRotation(incremental, a, b)) {
        last_incremental_ = Mat4::identity();
        return false;
    }
    last_incremental_ = incremental;
    Mat4 candidate = incremental * matrix_;  // Original Trackball.multiply(rot): rot * accumulated.
    if (!isFinite(candidate)) {
        diagnostics_.converged = false;
        return false;
    }

    diagnostics_.accumulated_residual = orthonormalityError(candidate);
    if (diagnostics_.accumulated_residual > kAccumulatedStabilizationResidual) {
        std::size_t stabilizationIterations = 0;
        double stabilizationError = 0.0;
        if (!orthonormalizeRows(candidate, kAccumulatedConvergenceError, kAccumulatedMaxIterations,
                                stabilizationIterations, stabilizationError)) {
            diagnostics_.converged = false;
            return false;
        }
        diagnostics_.accumulation_stabilized = true;
        diagnostics_.accumulation_stabilization_iterations = stabilizationIterations;
        diagnostics_.accumulated_residual = orthonormalityError(candidate);
    }

    if (!isFinite(candidate)) {
        diagnostics_.converged = false;
        return false;
    }
    matrix_ = candidate;
    return true;
}

Vec4 Trackball4::transform(const Vec4& point) const { return matrix_ * point; }

bool Trackball4::computeRotation(Mat4& rotation, const Vec4& a, const Vec4& b) {
    diagnostics_ = {};
    if (!isFinite(a) || !isFinite(b) || length(a) <= 1e-12 || length(b) <= 1e-12) {
        diagnostics_.valid_input = false;
        diagnostics_.converged = false;
        rotation = Mat4::identity();
        return false;
    }
    // Literal Header.cs construction: I + 2 * (B-A) * transpose(A).
    rotation = Mat4::identity();
    for (std::size_t row = 0; row < 4; ++row) {
        for (std::size_t col = 0; col < 4; ++col) {
            rotation(row,col) += 2.0 * (b[row] - a[row]) * a[col];
        }
    }

    std::size_t iterations = 0;
    double totalError = 0.0;
    const bool converged = orthonormalizeRows(rotation, kOriginalConvergenceError, kMaxIterations,
                                               iterations, totalError);
    diagnostics_.iterations = iterations;
    diagnostics_.total_error = totalError;
    diagnostics_.orthonormality_residual = orthonormalityError(rotation);
    diagnostics_.converged = converged && isFinite(rotation);
    if (!diagnostics_.converged) {
        rotation = Mat4::identity();
        return false;
    }
    return true;
}

}  // namespace fourd
