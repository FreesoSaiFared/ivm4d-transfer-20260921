#include "core/tesseract.h"

#include <algorithm>
#include <array>
#include <cmath>

namespace fourd {

Tesseract::Tesseract(double halfExtent) : half_extent_(halfExtent) {
    if (!std::isfinite(half_extent_) || half_extent_ <= 0.0) half_extent_ = kDefaultHalfExtent;
    generate();
}

void Tesseract::generate() {
    // Original Unity nesting makes x the fastest-varying coordinate, then y, z, w.
    for (std::size_t i = 0; i < kVertexCount; ++i) {
        const double x = (i & 1U) ? half_extent_ : -half_extent_;
        const double y = (i & 2U) ? half_extent_ : -half_extent_;
        const double z = (i & 4U) ? half_extent_ : -half_extent_;
        const double w = (i & 8U) ? half_extent_ : -half_extent_;
        source_vertices_[i] = {x, y, z, w};
    }
    std::size_t edgeIndex = 0;
    for (std::size_t dimension = 0; dimension < 4; ++dimension) {
        const std::size_t bit = std::size_t{1} << dimension;
        for (std::size_t vertex = 0; vertex < kVertexCount; ++vertex) {
            if ((vertex & bit) == 0U) {
                edges_[edgeIndex++] = {static_cast<std::uint8_t>(vertex), static_cast<std::uint8_t>(vertex | bit)};
            }
        }
    }
    reset();
}

void Tesseract::reset() { transformed_vertices_ = source_vertices_; }

void Tesseract::applyRotation(const Mat4& rotation) {
    for (std::size_t i = 0; i < kVertexCount; ++i) transformed_vertices_[i] = rotation * source_vertices_[i];
}

bool Tesseract::validateTopology() const {
    std::array<unsigned, kVertexCount> degree{};
    std::array<std::array<bool, kVertexCount>, kVertexCount> seen{};
    for (const Edge& edge : edges_) {
        const std::size_t a = edge[0];
        const std::size_t b = edge[1];
        if (a >= kVertexCount || b >= kVertexCount || a == b || seen[a][b] || seen[b][a]) return false;
        seen[a][b] = seen[b][a] = true;
        ++degree[a];
        ++degree[b];
        unsigned differences = 0;
        for (std::size_t axis = 0; axis < 4; ++axis)
            if (std::abs(source_vertices_[a][axis] - source_vertices_[b][axis]) > 1e-12) ++differences;
        if (differences != 1U) return false;
    }
    return std::all_of(degree.begin(), degree.end(), [](unsigned value) { return value == 4U; });
}

}  // namespace fourd
