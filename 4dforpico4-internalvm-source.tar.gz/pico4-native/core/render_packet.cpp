#include "core/render_packet.h"

#include <cmath>

namespace fourd {

RenderPacket makeRenderPacket(const Tesseract& tesseract,
                              const Interaction& interaction,
                              const Projection4& projection) {
    RenderPacket packet;
    packet.edges = tesseract.edges();
    packet.object_translation = interaction.translation();
    packet.uniform_scale = interaction.scale();
    packet.projection_mode = interaction.projectionMode();
    packet.valid = isFinite(packet.object_translation) && std::isfinite(packet.uniform_scale);

    for (std::size_t i = 0; i < Tesseract::kVertexCount; ++i) {
        const Vec4 transformed = interaction.trackball().transform(tesseract.sourceVertices()[i]);
        packet.transformed_w[i] = transformed.w;
        const Vec3 projected = projection.project(transformed, packet.projection_mode);
        packet.projected_vertices[i] = packet.object_translation + projected * packet.uniform_scale;
        packet.valid = packet.valid && isFinite(transformed) && std::isfinite(packet.transformed_w[i]) &&
                       isFinite(packet.projected_vertices[i]);
    }
    return packet;
}

}  // namespace fourd
