#pragma once

#include "core/math4.h"
#include "core/projection4.h"
#include "core/trackball4.h"
#include "core/trackball_mapping.h"

namespace fourd {

struct ButtonFrame {
    bool down{false};
    bool held{false};
    bool up{false};
    bool active() const { return !up && (down || held); }
};

struct FrameInput {
    Vec3 rightControllerPosition{};
    Vec3 leftControllerPosition{};
    Vec3 trackballCenter{};
    ButtonFrame trigger{};
    ButtonFrame rightSqueeze{};
    ButtonFrame leftSqueeze{};
    bool resetCommand{false};
    bool projectionToggleCommand{false};
    bool cancelManipulations{false};
};

struct InteractionConfig {
    TrackballMappingConfig mapping{};
    double minimumScale{0.2};
    double maximumScale{10.0};
    double defaultScale{1.0};
    Vec3 defaultTranslation{};
    ProjectionMode defaultProjection{ProjectionMode::Orthographic};
};

class Interaction {
public:
    explicit Interaction(InteractionConfig config = {});
    void reset();
    void update(const FrameInput& input);
    void cancel();

    const Trackball4& trackball() const { return trackball_; }
    const Vec3& translation() const { return translation_; }
    double scale() const { return scale_; }
    ProjectionMode projectionMode() const { return projection_mode_; }
    const InteractionConfig& config() const { return config_; }

private:
    enum class ManipulationMode { None, Translate, Scale };
    void beginTranslate(const Vec3& rightPosition);
    void beginScale(const Vec3& leftPosition, const Vec3& rightPosition);

    InteractionConfig config_{};
    Trackball4 trackball_{};
    Vec3 translation_{};
    double scale_{1.0};
    ProjectionMode projection_mode_{ProjectionMode::Orthographic};

    bool trigger_active_{false};
    bool has_last_trackball_point_{false};
    Vec4 last_trackball_point_{};

    ManipulationMode manipulation_mode_{ManipulationMode::None};
    Vec3 translation_offset_{};
    double scale_base_distance_{1.0};
    double scale_base_value_{1.0};
};

}  // namespace fourd
