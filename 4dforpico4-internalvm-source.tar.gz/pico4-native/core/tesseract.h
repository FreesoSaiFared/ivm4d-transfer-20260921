#pragma once

#include "core/math4.h"

#include <array>
#include <cstddef>
#include <cstdint>

namespace fourd {

using Edge = std::array<std::uint8_t, 2>;

class Tesseract {
public:
    static constexpr std::size_t kVertexCount = 16;
    static constexpr std::size_t kEdgeCount = 32;
    static constexpr double kDefaultHalfExtent = 0.175;

    explicit Tesseract(double halfExtent = kDefaultHalfExtent);
    void reset();
    void applyRotation(const Mat4& rotation);
    bool validateTopology() const;

    double halfExtent() const { return half_extent_; }
    const std::array<Vec4, kVertexCount>& sourceVertices() const { return source_vertices_; }
    const std::array<Vec4, kVertexCount>& transformedVertices() const { return transformed_vertices_; }
    const std::array<Edge, kEdgeCount>& edges() const { return edges_; }

private:
    void generate();

    double half_extent_{kDefaultHalfExtent};
    std::array<Vec4, kVertexCount> source_vertices_{};
    std::array<Vec4, kVertexCount> transformed_vertices_{};
    std::array<Edge, kEdgeCount> edges_{};
};

}  // namespace fourd
