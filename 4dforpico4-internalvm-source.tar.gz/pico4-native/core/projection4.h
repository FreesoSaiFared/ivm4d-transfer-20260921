#pragma once

#include "core/math4.h"

namespace fourd {

enum class ProjectionMode {
    Orthographic = 0,
    WPerspective = 1,
};

class Projection4 {
public:
    explicit Projection4(double distance = 2.0, double denominatorEpsilon = 1e-6);
    void setDistance(double distance);
    void setDenominatorEpsilon(double epsilon);
    double distance() const { return distance_; }
    double denominatorEpsilon() const { return denominator_epsilon_; }
    Vec3 project(const Vec4& point, ProjectionMode mode) const;

private:
    static double safeDivide(double numerator, double denominator);
    double distance_{2.0};
    double denominator_epsilon_{1e-6};
};

}  // namespace fourd
