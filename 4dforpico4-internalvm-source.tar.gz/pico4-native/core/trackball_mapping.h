#pragma once

#include "core/math4.h"

namespace fourd {

struct TrackballMappingConfig {
    double gain{8.0 / 3.0};
    double radius{1.0};
};

struct TrackballMappingResult {
    Vec4 point{0.0, 0.0, 0.0, 1.0};
    bool valid{true};
    bool clamped{false};
};

TrackballMappingResult mapTrackball(const Vec3& controllerPosition,
                                    const Vec3& center,
                                    const TrackballMappingConfig& config = {});

}  // namespace fourd
