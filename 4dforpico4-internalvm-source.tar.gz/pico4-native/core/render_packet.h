#pragma once

#include "core/interaction.h"
#include "core/projection4.h"
#include "core/tesseract.h"

#include <array>

namespace fourd {

struct RenderPacket {
    std::array<Vec3, Tesseract::kVertexCount> projected_vertices{};
    std::array<Edge, Tesseract::kEdgeCount> edges{};
    std::array<double, Tesseract::kVertexCount> transformed_w{};
    Vec3 object_translation{};
    double uniform_scale{1.0};
    ProjectionMode projection_mode{ProjectionMode::Orthographic};
    bool valid{false};
};

RenderPacket makeRenderPacket(const Tesseract& tesseract,
                              const Interaction& interaction,
                              const Projection4& projection);

}  // namespace fourd
