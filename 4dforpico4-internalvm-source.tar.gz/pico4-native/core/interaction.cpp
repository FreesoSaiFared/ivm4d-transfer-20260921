#include "core/interaction.h"

#include <algorithm>
#include <cmath>

namespace fourd {

Interaction::Interaction(InteractionConfig config) : config_(config) {
    if (!std::isfinite(config_.minimumScale) || config_.minimumScale <= 0.0) config_.minimumScale = 0.2;
    if (!std::isfinite(config_.maximumScale) || config_.maximumScale < config_.minimumScale) config_.maximumScale = 10.0;
    if (!std::isfinite(config_.defaultScale)) config_.defaultScale = 1.0;
    config_.defaultScale = std::clamp(config_.defaultScale, config_.minimumScale, config_.maximumScale);
    if (!isFinite(config_.defaultTranslation)) config_.defaultTranslation = {};
    reset();
}

void Interaction::reset() {
    trackball_.reset();
    translation_ = config_.defaultTranslation;
    scale_ = config_.defaultScale;
    projection_mode_ = config_.defaultProjection;
    cancel();
}

void Interaction::cancel() {
    trigger_active_ = false;
    has_last_trackball_point_ = false;
    manipulation_mode_ = ManipulationMode::None;
    translation_offset_ = {};
    scale_base_distance_ = 1.0;
    scale_base_value_ = scale_;
}

void Interaction::beginTranslate(const Vec3& rightPosition) {
    manipulation_mode_ = ManipulationMode::Translate;
    translation_offset_ = isFinite(rightPosition) ? translation_ - rightPosition : Vec3{};
}

void Interaction::beginScale(const Vec3& leftPosition, const Vec3& rightPosition) {
    manipulation_mode_ = ManipulationMode::Scale;
    const double handDistance = length(rightPosition - leftPosition);
    // Preserve the original Manager.cs fallback for a nearly coincident bilateral capture.
    scale_base_distance_ = (!std::isfinite(handDistance) || handDistance < 0.001) ? 1.0 : handDistance;
    scale_base_value_ = scale_;
}

void Interaction::update(const FrameInput& input) {
    if (input.resetCommand) {
        reset();
        return;
    }
    if (input.projectionToggleCommand)
        projection_mode_ = (projection_mode_ == ProjectionMode::Orthographic) ? ProjectionMode::WPerspective : ProjectionMode::Orthographic;

    const bool cancelled = input.cancelManipulations;
    const bool triggerNow = !cancelled && input.trigger.active();
    if (triggerNow) {
        const TrackballMappingResult mapped = mapTrackball(input.rightControllerPosition, input.trackballCenter, config_.mapping);
        if (mapped.valid) {
            if (!trigger_active_ || !has_last_trackball_point_) {
                last_trackball_point_ = mapped.point;
                has_last_trackball_point_ = true;
            } else {
                trackball_.rotate(last_trackball_point_, mapped.point);
                last_trackball_point_ = mapped.point;
            }
        } else {
            has_last_trackball_point_ = false;
        }
    } else {
        has_last_trackball_point_ = false;
    }
    trigger_active_ = triggerNow;

    const bool rightNow = !cancelled && input.rightSqueeze.active();
    const bool leftNow = !cancelled && input.leftSqueeze.active();
    const ManipulationMode desired = (rightNow && leftNow) ? ManipulationMode::Scale
                                    : rightNow ? ManipulationMode::Translate
                                               : ManipulationMode::None;
    if (desired != manipulation_mode_) {
        if (desired == ManipulationMode::Translate) beginTranslate(input.rightControllerPosition);
        else if (desired == ManipulationMode::Scale) beginScale(input.leftControllerPosition, input.rightControllerPosition);
        else manipulation_mode_ = ManipulationMode::None;
    }

    if (manipulation_mode_ == ManipulationMode::Translate && isFinite(input.rightControllerPosition)) {
        translation_ = input.rightControllerPosition + translation_offset_;
    } else if (manipulation_mode_ == ManipulationMode::Scale && isFinite(input.leftControllerPosition) && isFinite(input.rightControllerPosition)) {
        const double currentDistance = length(input.rightControllerPosition - input.leftControllerPosition);
        if (std::isfinite(currentDistance)) {
            const double ratio = currentDistance / scale_base_distance_;
            if (std::isfinite(ratio)) scale_ = std::clamp(scale_base_value_ * ratio, config_.minimumScale, config_.maximumScale);
        }
    }
}

}  // namespace fourd
