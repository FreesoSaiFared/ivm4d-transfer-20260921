#pragma once

#include <array>
#include <cstddef>

namespace fourd {

struct Vec3 {
    double x{0.0};
    double y{0.0};
    double z{0.0};
    constexpr Vec3() = default;
    constexpr Vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}
    constexpr Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    constexpr Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    constexpr Vec3 operator*(double s) const { return {x * s, y * s, z * s}; }
    constexpr Vec3 operator/(double s) const { return {x / s, y / s, z / s}; }
    Vec3& operator+=(const Vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
};
constexpr Vec3 operator*(double s, const Vec3& v) { return v * s; }

struct Vec4 {
    double x{0.0};
    double y{0.0};
    double z{0.0};
    double w{0.0};
    constexpr Vec4() = default;
    constexpr Vec4(double x_, double y_, double z_, double w_) : x(x_), y(y_), z(z_), w(w_) {}
    double& operator[](std::size_t index);
    double operator[](std::size_t index) const;
    constexpr Vec4 operator+(const Vec4& o) const { return {x + o.x, y + o.y, z + o.z, w + o.w}; }
    constexpr Vec4 operator-(const Vec4& o) const { return {x - o.x, y - o.y, z - o.z, w - o.w}; }
    constexpr Vec4 operator*(double s) const { return {x * s, y * s, z * s, w * s}; }
    constexpr Vec4 operator/(double s) const { return {x / s, y / s, z / s, w / s}; }
};
constexpr Vec4 operator*(double s, const Vec4& v) { return v * s; }

double dot(const Vec3& a, const Vec3& b);
double dot(const Vec4& a, const Vec4& b);
double lengthSquared(const Vec3& value);
double lengthSquared(const Vec4& value);
double length(const Vec3& value);
double length(const Vec4& value);
Vec3 normalize(const Vec3& value, double epsilon = 1e-12);
Vec4 normalize(const Vec4& value, double epsilon = 1e-12);
bool isFinite(const Vec3& value);
bool isFinite(const Vec4& value);

struct Mat4 {
    std::array<double, 16> values{};
    static Mat4 identity();
    double& operator()(std::size_t row, std::size_t column);
    double operator()(std::size_t row, std::size_t column) const;
};

Mat4 operator*(const Mat4& a, const Mat4& b);
Vec4 operator*(const Mat4& matrix, const Vec4& vector);
Mat4 transpose(const Mat4& matrix);
double determinant(const Mat4& matrix);
double orthonormalityError(const Mat4& matrix);
bool isFinite(const Mat4& matrix);
double maxAbsDifference(const Mat4& a, const Mat4& b);

}  // namespace fourd
