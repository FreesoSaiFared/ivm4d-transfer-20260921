#include "core/trackball_mapping.h"

#include <algorithm>
#include <cmath>

namespace fourd {

TrackballMappingResult mapTrackball(const Vec3& controllerPosition,
                                    const Vec3& center,
                                    const TrackballMappingConfig& config) {
    TrackballMappingResult result;
    if (!isFinite(controllerPosition) || !isFinite(center) || !std::isfinite(config.gain) ||
        !std::isfinite(config.radius) || config.radius <= 1e-12) {
        result.valid = false;
        return result;
    }

    // Divide by configurable radius so the returned 4D vector remains unit length.
    // For the original radius=1 this is exactly (controller-center) * 8/3.
    const Vec3 xyz = (controllerPosition - center) * (config.gain / config.radius);
    const double r2 = lengthSquared(xyz);
    if (!std::isfinite(r2)) {
        result.valid = false;
        return result;
    }
    if (r2 < 1.0) {
        result.point = {xyz.x, xyz.y, xyz.z, std::sqrt(std::max(0.0, 1.0 - r2))};
        return result;
    }

    const double r = std::sqrt(r2);
    if (!std::isfinite(r) || r <= 1e-12) {
        result.valid = false;
        return result;
    }
    const Vec3 unit = xyz / r;
    result.point = {unit.x, unit.y, unit.z, 0.0};
    result.clamped = true;
    return result;
}

}  // namespace fourd
