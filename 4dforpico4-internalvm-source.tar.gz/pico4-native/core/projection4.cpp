#include "core/projection4.h"

#include <cmath>
#include <limits>

namespace fourd {

Projection4::Projection4(double distance, double denominatorEpsilon) {
    setDistance(distance);
    setDenominatorEpsilon(denominatorEpsilon);
}

void Projection4::setDistance(double distance) {
    distance_ = std::isfinite(distance) ? distance : 2.0;
}
void Projection4::setDenominatorEpsilon(double epsilon) {
    denominator_epsilon_ = (std::isfinite(epsilon) && epsilon > 0.0) ? epsilon : 1e-6;
}

double Projection4::safeDivide(double numerator, double denominator) {
    if (!std::isfinite(numerator) || !std::isfinite(denominator) || denominator == 0.0) return 0.0;
    const long double value = static_cast<long double>(numerator) / static_cast<long double>(denominator);
    const long double limit = static_cast<long double>(std::numeric_limits<double>::max());
    if (value > limit) return std::numeric_limits<double>::max();
    if (value < -limit) return -std::numeric_limits<double>::max();
    return static_cast<double>(value);
}

Vec3 Projection4::project(const Vec4& point, ProjectionMode mode) const {
    if (!isFinite(point)) return {};
    if (mode == ProjectionMode::Orthographic) return {point.x, point.y, point.z};
    double denominator = distance_ - point.w;
    if (!std::isfinite(denominator)) return {};
    if (std::abs(denominator) < denominator_epsilon_)
        denominator = std::copysign(denominator_epsilon_, denominator == 0.0 ? 1.0 : denominator);
    return {safeDivide(point.x, denominator), safeDivide(point.y, denominator), safeDivide(point.z, denominator)};
}

}  // namespace fourd
