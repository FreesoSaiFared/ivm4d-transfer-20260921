#pragma once

#include "core/math4.h"

#include <cstddef>

namespace fourd {

struct TrackballDiagnostics {
    std::size_t iterations{0};
    double total_error{0.0};
    double orthonormality_residual{0.0};
    double accumulated_residual{0.0};
    std::size_t accumulation_stabilization_iterations{0};
    bool accumulation_stabilized{false};
    bool converged{true};
    bool valid_input{true};
};

class Trackball4 {
public:
    static constexpr double kOriginalConvergenceError = 1e-5;
    static constexpr std::size_t kMaxIterations = 128;
    static constexpr double kAccumulatedStabilizationResidual = 1e-9;
    static constexpr double kAccumulatedConvergenceError = 1e-24;
    static constexpr std::size_t kAccumulatedMaxIterations = 32;

    Trackball4();
    void reset();
    bool rotate(const Vec4& a, const Vec4& b);
    Vec4 transform(const Vec4& point) const;

    const Mat4& matrix() const { return matrix_; }
    const Mat4& lastIncremental() const { return last_incremental_; }
    const TrackballDiagnostics& diagnostics() const { return diagnostics_; }

private:
    bool computeRotation(Mat4& rotation, const Vec4& a, const Vec4& b);

    Mat4 matrix_{Mat4::identity()};
    Mat4 last_incremental_{Mat4::identity()};
    TrackballDiagnostics diagnostics_{};
};

}  // namespace fourd
