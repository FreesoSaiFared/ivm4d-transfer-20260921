#include "core/math4.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace fourd {

double& Vec4::operator[](std::size_t i) {
    switch (i) { case 0: return x; case 1: return y; case 2: return z; case 3: return w; default: throw std::out_of_range("Vec4 index"); }
}
double Vec4::operator[](std::size_t i) const {
    switch (i) { case 0: return x; case 1: return y; case 2: return z; case 3: return w; default: throw std::out_of_range("Vec4 index"); }
}

double dot(const Vec3& a, const Vec3& b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
double dot(const Vec4& a, const Vec4& b) { return a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w; }
double lengthSquared(const Vec3& v) { return dot(v, v); }
double lengthSquared(const Vec4& v) { return dot(v, v); }
double length(const Vec3& v) { return std::sqrt(lengthSquared(v)); }
double length(const Vec4& v) { return std::sqrt(lengthSquared(v)); }

Vec3 normalize(const Vec3& v, double epsilon) {
    const double n = length(v);
    return (!std::isfinite(n) || n <= epsilon) ? Vec3{} : v / n;
}
Vec4 normalize(const Vec4& v, double epsilon) {
    const double n = length(v);
    return (!std::isfinite(n) || n <= epsilon) ? Vec4{} : v / n;
}
bool isFinite(const Vec3& v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }
bool isFinite(const Vec4& v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) && std::isfinite(v.w); }

Mat4 Mat4::identity() {
    Mat4 out;
    for (std::size_t i = 0; i < 4; ++i) out(i, i) = 1.0;
    return out;
}
double& Mat4::operator()(std::size_t row, std::size_t col) { return values[row * 4 + col]; }
double Mat4::operator()(std::size_t row, std::size_t col) const { return values[row * 4 + col]; }

Mat4 operator*(const Mat4& a, const Mat4& b) {
    Mat4 out;
    for (std::size_t r = 0; r < 4; ++r) {
        for (std::size_t c = 0; c < 4; ++c) {
            double sum = 0.0;
            for (std::size_t k = 0; k < 4; ++k) sum += a(r,k) * b(k,c);
            out(r,c) = sum;
        }
    }
    return out;
}
Vec4 operator*(const Mat4& m, const Vec4& v) {
    Vec4 out;
    for (std::size_t r = 0; r < 4; ++r) {
        double sum = 0.0;
        for (std::size_t c = 0; c < 4; ++c) sum += m(r,c) * v[c];
        out[r] = sum;
    }
    return out;
}
Mat4 transpose(const Mat4& m) {
    Mat4 out;
    for (std::size_t r = 0; r < 4; ++r)
        for (std::size_t c = 0; c < 4; ++c)
            out(c,r) = m(r,c);
    return out;
}

double determinant(const Mat4& m) {
    long double a[4][4]{};
    for (std::size_t r = 0; r < 4; ++r)
        for (std::size_t c = 0; c < 4; ++c)
            a[r][c] = static_cast<long double>(m(r,c));
    long double det = 1.0L;
    int sign = 1;
    for (std::size_t p = 0; p < 4; ++p) {
        std::size_t best = p;
        for (std::size_t r = p + 1; r < 4; ++r)
            if (std::abs(a[r][p]) > std::abs(a[best][p])) best = r;
        if (std::abs(a[best][p]) <= std::numeric_limits<long double>::epsilon()) return 0.0;
        if (best != p) {
            for (std::size_t c = 0; c < 4; ++c) std::swap(a[p][c], a[best][c]);
            sign = -sign;
        }
        const long double pivot = a[p][p];
        det *= pivot;
        for (std::size_t r = p + 1; r < 4; ++r) {
            const long double factor = a[r][p] / pivot;
            for (std::size_t c = p + 1; c < 4; ++c) a[r][c] -= factor * a[p][c];
        }
    }
    return static_cast<double>(det * static_cast<long double>(sign));
}

double orthonormalityError(const Mat4& m) {
    const Mat4 product = m * transpose(m);
    double maxError = 0.0;
    for (std::size_t r = 0; r < 4; ++r) {
        for (std::size_t c = 0; c < 4; ++c) {
            const double target = (r == c) ? 1.0 : 0.0;
            maxError = std::max(maxError, std::abs(product(r,c) - target));
        }
    }
    return maxError;
}
bool isFinite(const Mat4& m) {
    for (double v : m.values) if (!std::isfinite(v)) return false;
    return true;
}
double maxAbsDifference(const Mat4& a, const Mat4& b) {
    double result = 0.0;
    for (std::size_t i = 0; i < a.values.size(); ++i) result = std::max(result, std::abs(a.values[i] - b.values[i]));
    return result;
}

}  // namespace fourd
